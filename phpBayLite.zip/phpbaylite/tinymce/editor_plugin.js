(function() {
// Load TinyMCE Plugin code based on whether using TinyMCE3 or TinyMCE4
if (tinymce.majorVersion == 3) {
	//Load Custom phpBay Lite Button via TinyMce3
	tinymce.create('tinymce.plugins.phpBayLitePlugin', {
		init : function(ed, url) {
			var t = this;
			ed.onInit.add(function() {
				if (ed.settings.content_css !== false) {
					//This is necessry to load in any external css styles.
					//In this case, we want an image behind the MCE SplitButton
					//so we use CSS styling to place the button in the SplitButton
					dom = ed.windowManager.createInstance('tinymce.dom.DOMUtils', document);
					dom.loadCSS(url + '/style.css');
				}
			});
	  
			//This code builds popup window command for the first option in the SplitButton.
			//We need to pass the tinyMCE base URL so that once in the popup, we can tell it
			//to send the options in a pre-defined [phpbay] tag back to the Wordpress editor.
			ed.addCommand('phpBayLiteOptionsPage1', function() {
				editor.windowManager.open( {
							title: 'phpBay Lite Shortcode Generator',
							items: {
								type: 'form',
								layout: 'grid',
								columns: 2,
								defaults: {
									type: 'textbox',
									maxWidth: 200
								},
								items: [
									{label: 'Keywords:', name: 'keywords', maxWidth: 200},
									{label: 'Country:',
										minWidth: 90,
										name: 'siteid',
										type: 'listbox',
										text: 'None',
										maxWidth: null,
										values: [
											{text: 'United States', value: '1'},
											{text: 'Australia', value: '4'},
											{text: 'Austria', value: '3'},
											{text: 'Belgium', value: '5'},
											{text: 'Canada', value: '7'},
											{text: 'France', value: '10'},
											{text: 'Germany', value: '11'},
											{text: 'Ireland', value: '2'},
											{text: 'Italy', value: '12'},
											{text: 'Netherlands', value: '16'},
											{text: 'Spain', value: '13'},
											{text: 'Switzerland', value: '14'},
											{text: 'United Kingdom', value: '15'},
										],
										onPostRender: function() {
											// Set the global siteid as default
											if (pbl_plugin.siteid > '') {
												this.value(pbl_plugin.siteid);
											}
										}
									},
									{label: 'Number of Results:', name: 'number', maxWidth: 40},
									{label: 'Custom ID:', name: 'customid'},
									{label: 'Sort Order:',
										minWidth: 90,
										name: 'sortorder',
										type: 'listbox',
										text: 'None',
										maxWidth: null,
										values: [
											{text: 'Best Match', value: 'BestMatch'},
											{text: 'Time Ending Soonest', value: 'EndTimeSoonest'},
											{text: 'Time Newly Listed', value: 'StartTimeNewest'},
											{text: '(Price + Shipping) Lowest First', value: 'PricePlusShippingLowest'},
											{text: '(Price + Shipping) Highest First', value: 'PricePlusShippingHighest'},
										],
										onPostRender: function() {
											// Set EndTimeSoonest as default default
											this.value('EndTimeSoonest');
										}
									},
								]
						},
						onsubmit: function( e ) {
							if (e.data.keywords > "") {
								var shortcode = '[phpbaylite keywords="' + e.data.keywords + '"';
								if (e.data.siteid > "") {
									shortcode += ' siteid="' + e.data.siteid + '"';
								}
								if (e.data.number > "") {
									shortcode += ' num="' + e.data.number + '"';
								}
								if (e.data.customid > "") {
									shortcode += ' customid="' + e.data.customid + '"';
								}
								if (e.data.sortorder > "") {
									shortcode += ' sortorder="' + e.data.sortorder + '"';
								}
								shortcode += "]";
								editor.insertContent(shortcode);
							}
						}
					});
			});

		},

		getInfo : function() {
			return {
				longname : 'phpBay Lite',
				author : 'Wade Wells',
				authorurl : 'http://www.phpbay.com',
				infourl : 'http://www.phpbay.com',
				version : tinymce.majorVersion + "." + tinymce.minorVersion
			};
		},

		//This creates the actual SplitButton Control.  To it, we add the Menu Titles.
		//The first title is set to disabled, as it's more of an instruction to select one
		//of the options below.  The next two are the actual menu items along with the
		//name of the Command we created earlier for each of these items (the popup pages).
		createControl: function(n, cm, url) {
			switch (n) {
				case 'phpBayLite':
					var c = cm.createSplitButton('phpBayLite', {
						title : 'phpBay Lite',
					'	class': 'phpBayLiteSplitButton'
					});

					c.onRenderMenu.add(function(c, m) {
						m.add({title : 'phpBay Lite - Select Option Below', 'class' : 'mceMenuItemTitle'}).setDisabled(1);
						m.add({title : 'Search Results', cmd : 'phpBayLiteOptionsPage1'});
					});
					return c;
			}
        	return null;
		}
	});
	//Register the tinyMCE Plugin with an appropriate name so as not to conflict with other plugins.
	tinymce.PluginManager.add('phpBayLite', tinymce.plugins.phpBayLitePlugin);
} else {
	//Load Custom phpBay Pro Button via TinyMce4
	tinymce.PluginManager.add('phpBayLite', function(editor, url) {
		editor.on('init', function() {
			//load in custom CSS for splitbutton
			tinymce.DOM.loadCSS(url + '/style.css');
		});

		editor.addButton('phpBayLite', {
			type: 'menubutton',
			tooltip: 'phpBay Lite',
			icon: false,
			classes: "widget btn splitbtn menubtn phpBayLiteSplitButton",
				menu: [
					{text: 'Search Results', onclick: function() {
						editor.windowManager.open( {
							title: 'phpBay Lite Shortcode Generator',
							items: {
								type: 'form',
								layout: 'grid',
								columns: 2,
								defaults: {
									type: 'textbox',
									maxWidth: 200
								},
								items: [
									{label: 'Keywords:', name: 'keywords', maxWidth: 200},
									{label: 'Country:',
										minWidth: 90,
										name: 'siteid',
										type: 'listbox',
										text: 'None',
										maxWidth: null,
										values: [
											{text: 'United States', value: '1'},
											{text: 'Australia', value: '4'},
											{text: 'Austria', value: '3'},
											{text: 'Belgium', value: '5'},
											{text: 'Canada', value: '7'},
											{text: 'France', value: '10'},
											{text: 'Germany', value: '11'},
											{text: 'Ireland', value: '2'},
											{text: 'Italy', value: '12'},
											{text: 'Netherlands', value: '16'},
											{text: 'Spain', value: '13'},
											{text: 'Switzerland', value: '14'},
											{text: 'United Kingdom', value: '15'},
										],
										onPostRender: function() {
											// Set the global siteid as default
											if (pbl_plugin.siteid > '') {
												this.value(pbl_plugin.siteid);
											}
										}
									},
									{label: 'Number of Results:', name: 'number', maxWidth: 40},
									{label: 'Custom ID:', name: 'customid'},
									{label: 'Sort Order:',
										minWidth: 90,
										name: 'sortorder',
										type: 'listbox',
										text: 'None',
										maxWidth: null,
										values: [
											{text: 'Best Match', value: 'BestMatch'},
											{text: 'Time Ending Soonest', value: 'EndTimeSoonest'},
											{text: 'Time Newly Listed', value: 'StartTimeNewest'},
											{text: '(Price + Shipping) Lowest First', value: 'PricePlusShippingLowest'},
											{text: '(Price + Shipping) Highest First', value: 'PricePlusShippingHighest'},
										],
										onPostRender: function() {
											// Set EndTimeSoonest as default default
											this.value('EndTimeSoonest');
										}
									},
								]
						},
						onsubmit: function( e ) {
							if (e.data.keywords > "") {
								var shortcode = '[phpbaylite keywords="' + e.data.keywords + '"';
								if (e.data.siteid > "") {
									shortcode += ' siteid="' + e.data.siteid + '"';
								}
								if (e.data.number > "") {
									shortcode += ' num="' + e.data.number + '"';
								}
								if (e.data.customid > "") {
									shortcode += ' customid="' + e.data.customid + '"';
								}
								if (e.data.sortorder > "") {
									shortcode += ' sortorder="' + e.data.sortorder + '"';
								}
								shortcode += "]";
								editor.insertContent(shortcode);
							}
						}
					});
					}}				]
			//}
		});

	});
	
} //end TinyMCE version check
})();