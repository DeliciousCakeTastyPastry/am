<?php
#########################################################################
#                                                                       #
#                  phpBay Lite 2.x Wordpress Plugin                     #
#                            www.phpbay.com                             #
#                                                                       #
#########################################################################
# COPYRIGHT NOTICE                                                      #
# Copyright 2006-2015 phpBay LLC.  All Rights Reserved.                 #
#                                                                       #
# This script may be only used and modified in accordance to the        #
# license agreement attached (eula.txt) except where expressly          #
# noted within commented areas of the code body. This copyright notice  #
# and the comments above and below must remain intact at all times.     #
# By using this code you agree to indemnify phpBay LLC, its             #
# corporate agents and affiliates from any liability that might arise   #
# from its use.                                                         #
#                                                                       #
# Selling the code for this program without prior written consent is    #
# expressly forbidden and in violation of Domestic and International    #
# copyright laws.                                                       #
#########################################################################
class phpBayLite{
	var $epn = array();
	var $xml = array();
	var $path = array();
	var $details = array();
	var $settings = array();
##################################################################################################

function SetPaths() {
	$this->path = array();
	if (function_exists("wp_get_single_post")) {
		#URL Paths
		$this->path["blog_url"] = get_bloginfo("wpurl");
		$sub_folder = parse_url($this->path["blog_url"]);
		if (isset($sub_folder['path'])) {
			$this->path["sub_folder"] = ltrim($sub_folder['path'], "/");
		}
		$this->path["blog_url"] .= "/";
		$this->path["images_url"] = PBL_PLUGIN_URL . "media/images/";
		$this->path["error_url"] = PBL_PLUGIN_URL . "media/error.html";
	}
	if ((isset($this->epn["Debug"])) && ($this->epn["Debug"] == true)){
		echo "=============================================================<br>\r\n";
		foreach($this->path as $key_name => $key_value) {echo $key_name . " = " . $key_value . "<br>\r\n";}
		echo "var_dump<br>\r\n";
		var_dump(explode(DS, dirname(__FILE__))) . "<br>\r\n";
		if (strncasecmp(PHP_OS, 'WIN', 3) == 0) {
			$os = "Windows based server.";
		} else {
			$os = "Linux based server.";
		}
		echo "<br>\r\nserver os = " . $os . "<br>\r\n";
		echo "seperator = " . DS . "<br>\r\n";
		echo "=============================================================<br>\r\n";
	}
}

##################################################################################################

function GetSettings() {
	if (empty($this->settings)) {
		$this->settings = get_option("pbl_options");
		foreach ($this->settings as $key => $option){
			$this->settings[$key] = $option;}
	}
	if (isset($this->settings["SkimLinks"])) {if (($this->settings["SkimLinks"] == "1") && ($this->settings["SkimLinksID"] > "")){$this->settings["SkimLinks"] = true;}else{$this->settings["SkimLinks"]=false;}}
	if ((isset($this->settings["VigLinksID"])) && ($this->settings["VigLinks"] == "1") && ($this->settings["VigLinksID"] > "")){$this->settings["VigLinks"] = true;}else{$this->settings["VigLinks"]=false;}
	if ((isset($this->settings["SortOrder"])) && ($this->settings["SortOrder"] > "")){$this->epn["SortOrder"] = $this->settings["SortOrder"];}
	if(isset($this->settings["SiteID"])) {$this->epn["SiteID"] = $this->settings["SiteID"];}
	if(isset($this->settings["CampaignID"])) {$this->epn["CampaignID"] = $this->settings["CampaignID"];}
}

##################################################################################################

function GetShortCode($atts) {
	if(isset($atts["keywords"])){$this->epn["Keywords"] = $atts["keywords"];}
	$category = get_the_category();
	if(isset($this->epn["Keywords"])) {
		$this->epn["Keywords"] = str_replace("{title}", the_title("", "", false), $this->epn["Keywords"]);
		if(isset($post_id)) {$this->epn["Keywords"] = str_replace("{keywords}", get_post_meta($post_id, "keywords", true), $this->epn["Keywords"]);}
		$this->epn["Keywords"] = str_replace("{category}", $category[0]->cat_name, $this->epn["Keywords"]);
	}
	if(isset($atts["num"])){$this->epn["NumListings"] = (int)$atts["num"];} else {$this->epn["NumListings"] = 100;}
	if(isset($atts["siteid"])){$this->epn["SiteID"] = $atts["siteid"];}
	if(isset($atts["customid"])){$this->epn["CustomID"] = $atts["customid"];}
	if(isset($this->epn["CustomID"])) {$this->epn["CustomID"] = str_replace(" ", "+", $this->epn["CustomID"]);}
	if(isset($atts["sortorder"])){$this->epn["SortOrder"] = $atts["sortorder"];}
	if(isset($atts["debug"])){if (strtolower($atts["debug"]) == "true"){$this->epn["Debug"] = true;error_reporting(E_ALL & ~E_NOTICE);}else{$this->epn["Debug"] = false;}}

	#keywords
	$pos = strpos($this->epn["Keywords"], "(");
	if ($pos === false) {
		$temp = explode(",", $this->epn["Keywords"]);
//echo "keywords after explode = " . $this->epn["Keywords"] . "<br />\r\n";
		if (count($temp) > 1) {
//echo "inside count...<br />\r\n";
			$count = count($temp);
			$i = 1;
			$this->epn["Keywords"] = "(";
			foreach ($temp as $keyword) {
				$this->epn["Keywords"] .= $keyword;
				if ($i < $count) {$this->epn["Keywords"] .= ",";}
				$i++;
			}
			$this->epn["Keywords"] .= ")";
		}
	}

	unset($atts);
}

##################################################################################################

function BuildQuery() {
	$this->epn["url"] = "";
	#################################
	# keyword
	$this->epn["url"] .= "keyword=";
	# check for -(keyword
	$this->epn["url"] .= urlencode($this->epn["Keywords"]);
	#################################
	# SortOrder
	if ($this->epn["SortOrder"] > "") {
		$this->epn["url"] .= "&sortOrder=" . $this->epn["SortOrder"];
	} else {
		$this->epn["url"] .= "&sortOrder=EndTimeSoonest";
	}
	#################################
	# Site ID
	if ($this->epn["SiteID"] > "") {
		$this->epn["url"] .= "&programid=" . $this->epn["SiteID"];
	} else {
		$this->epn["url"] .= "&programid=1";
	}
	#################################
	# Campaign ID
	if ($this->settings["SkimLinks"] || $this->settings["VigLinksID"]) {
		# create a psuedo campaign id to use in Ebay query
		$x = "";
		for ($i = 0; $i < 8; $i++) {
			$x .= mt_rand(1,9);
		}
		$this->epn["url"] .= "&campaignid=" . $x;
	} else {
		$this->epn["url"] .= "&campaignid=" . $this->epn["CampaignID"];
	}
	#################################
	# Custom ID
	if ((isset($this->epn["CustomID"])) && ($this->epn["CustomID"] > "")) {
		$this->epn["url"] .= "&customid=" . $this->epn["CustomID"];
	}
	#################################
	#Listing Type
	$this->epn["url"] .= "&listingType1=All";
	#################################
	$this->epn["url"] .= "&toolid=10039&lgeo=1&feedType=rss";
	#################################
	# Selective URL Encode
	$this->epn["url"] = str_replace(" ", "+", $this->epn["url"]);
	$this->epn["url"] = str_replace(",", "%2C", $this->epn["url"]);
	$this->epn["url"] = str_replace("(", "%28", $this->epn["url"]);
	$this->epn["url"] = str_replace(")", "%29", $this->epn["url"]);
	# Base URL + Options
	$this->epn["url"] = "http://rest.ebay.com/epn/v1/find/item.rss?" . $this->epn["url"];
}

##################################################################################################

function ExecQuery() {
	$session = curl_init($this->epn["url"]);
	curl_setopt($session, CURLOPT_CONNECTTIMEOUT, 20);
	curl_setopt($session, CURLOPT_TIMEOUT, 20);
	curl_setopt($session, CURLOPT_HEADER, false);
	curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
	if ((isset($this->epn["Debug"])) && ($this->epn["Debug"])) {
		$time_start = microtime(true);
		echo "Ebay query start time: " . $time_start . "<br />\r\n";
	}
	$response = curl_exec($session);
	$error = curl_errno($session);
	$this->epn["CURL_Error"] = false;
	if ($error > 0) {
    	$this->epn["CURL_Error"] = true;
		$this->epn["CURL_ErrorMessage"] = "CURL error code = " . $error . ".  (" . curl_error($session) . ")";
	}
	curl_close($session);
	$this->epn["Query"] = true;
	if ((isset($this->epn["Debug"])) && ($this->epn["Debug"])) {
		$time_end = microtime(true);
		echo "Ebay query end time: " . $time_end . "<br />\r\n";
		echo "Ebay query total time: <strong>" . ($time_end - $time_start) . "</strong> seconds.<br />\r\n";
		$time_start = microtime(true);
		echo "simplexml_load_string start time: " . $time_start . "<br />\r\n";
	}
	$response = str_replace("<e:","<",$response);
	$response = str_replace("</e:","</",$response);

	$this->epn["xmlError"] = "";
	$pos = strpos($response, "<");
	if ($pos === false) {
		$this->epn["xmlError"] = PBL_ERROR_EBAY_XML;
		return;
	}
	$this->xml = simplexml_load_string($response, 'SimpleXMLElement', LIBXML_NOCDATA);
	$orig_count = count($this->xml->channel->item);
	define("PBL_ORGINAL_ITEM_COUNT", $orig_count);

	$this->epn["TotalResults"] = count($this->xml->channel->item);
	if ((isset($this->epn["Debug"])) && ($this->epn["Debug"])) {
		if ($this->settings["RemoveDuplicates"]) {
			echo "Original Item Count = " . $orig_count . "<br />\r\n";
			echo count($bad_list) . " of those were removed as duplicates<br />\r\n";
			echo "Leaving a total of " . $this->epn["TotalResults"] . " results<br />\r\n";
		} else {
			echo "Total Results from Ebay: " . $this->epn["TotalResults"] . "<br />\r\n";
		}
		$time_end = microtime(true);
		echo "simplexml_load_string end time: " . $time_end . "<br />\r\n";
		echo "simplexml_load_string total time: <strong>" . ($time_end - $time_start) . "</strong> seconds.<br />\r\n";
		echo "<strong>EPN URL = </strong>" . $this->epn["url"] . "<br />\r\n";
		echo "<strong>Keywords = </strong>" . $this->epn["Keywords"] . "<br />\r\n";
		echo "<strong>Exclude Keywords = </strong>" . $this->epn["Exclude"] . "<br />\r\n";
		echo "<strong>EPN XML:</strong><br />\r\n";
		var_dump($this->xml);
	}
}

##################################################################################################

function LoadTemplate($file) {
	$this->epn["temp"] = false;
	$this->epn["path"] = $file;
	if (function_exists("file_get_contents") && (!PB_DISABLE_FILE_GET_CONTENTS)) {
		if (PB_USE_URL_WITH_FILE_GET_CONTENTS) {
			if ($this->epn["Debug"]){
				echo "<br>\r\n=============================================================<br>\r\n";
				echo "Attempting to load template files using file_get_contents(" . $this->epn["path"] . ")<br>\r\n";
			}
    		$this->epn["temp"] = @file_get_contents($this->epn["path"]);
		} else {
			//realpath(WP_PLUGIN_DIR . PB_SEP . "phpBay" . PB_SEP . "templates") . PB_SEP;
			$fgc_path = realpath(str_replace($this->path["blog_url"], ABSPATH, $this->epn["path"]));
			if ($this->epn["Debug"]){
				echo "<br>\r\n=============================================================<br>\r\n";
				echo "Attempting to load template files using file_get_contents(" . $fgc_path . ")<br>\r\n";
			}
    		$this->epn["temp"] = @file_get_contents($fgc_path);
		}
	}
    if ($this->epn["temp"] == false) {
		if ($this->epn["Debug"]){
			echo "<br>\r\n=============================================================<br>\r\n";
			echo "Attempting to load template files using CURL with file path of (" . $this->epn["path"] . ")<br>\r\n";
		}
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->epn["path"]);
		if ($this->settings["Godaddy"] == "1") {
			curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
			curl_setopt($ch, CURLOPT_PROXY,PB_CURL_PROXY);
		}
		if ((defined("PB_CURL_PORT")) && (is_int(PB_CURL_PORT))) {
			curl_setopt($ch, CURLOPT_PORT, PB_CURL_PORT);
		}
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$this->epn["temp"] = curl_exec($ch);
		curl_close($ch);
	}
	if (($this->epn["Debug"]) && ($this->epn["temp"] > "")){
		echo "Template file loaded successfully...<br>\r\n";
	}
   return $this->epn["temp"];
}

##################################################################################################

function DefineErrors() {
	define("PBL_ERROR_CAMPAIGN_ID", "To display Ebay listings, enter your Campaign ID in the phpBayLite Admin Dashboard.");
	define("PBL_ERROR_KEYWORD", "To display Ebay results, you must first enter a keyword or keyword phrase.  Please consult the user manual.");
	define("PBL_ERROR_SIMPLEXML", "phpBay Lite requires the function <u>'simplexml_load_string'</u> in order to function properly.  Please consult with your webhost to have this functionality installed.");
	define("PBL_ERROR_EBAY_XML", "Ebay has returned a malformed xml response.  This could be due to testing or a bug in the RSS2 Generator.");
	define("PBL_ERROR_CURL", "phpBay Lite requires the function 'curl_init' in order to function properly.  Please consult with your webhost to have this functionality installed.");
	define("PBL_ERROR_NO_RESULTS", 'No items matching the keyword phrase <u>"' . $this->epn["Keywords"] . '"</u> were found.  This could be due to the keyword phrase used, or could mean your server is unable to communicate with Ebays RSS2 Server.');
}

##################################################################################################

function CheckForErrors() {

    $this->epn["Error"] = false;
	$this->epn["ErrorMessage"] = "";
	$this->epn["WarningList"] = array("Fumble!","Foul Ball!","10 yard Penalty!","Mulligan","Out of Bounds!","Mule Muffins!");
	$this->epn["Warning"] = $this->epn["WarningList"][mt_rand(0, count($this->epn["WarningList"]) - 1)];
	if ((empty($this->epn["CampaignID"])) && (empty($this->settings["SkimLinksID"])) && (empty($this->settings["VigLinksID"]))) {$this->epn["ErrorMessage"] .= PBL_ERROR_CAMPAIGN_ID . "<br />\r\n"; $this->epn["Error"] = true;}
    if ((!isset($this->epn["Keywords"])) && (!isset($this->epn["Category"]))) {$this->epn["ErrorMessage"] .= PBL_ERROR_KEYWORD . "<br />\r\n"; $this->epn["Error"] = true;}
    if (!function_exists("simplexml_load_string")) {$this->epn["ErrorMessage"] .= PBL_ERROR_SIMPLEXML . "<br />\r\n"; $this->epn["Error"] = true;}
    if (!function_exists("curl_init")) {$this->epn["ErrorMessage"] .= PBL_ERROR_CURL . "<br />\r\n"; $this->epn["Error"] = true;}

	if ((isset($this->epn["xmlError"])) && ($this->epn["xmlError"] > "")) {
		$this->epn["Error"] = true;
		$this->epn["ErrorMessage"] .= PBL_ERROR_EBAY_XML . "<br />\r\n";
	}
	if ((count($this->xml->channel->item) == 0) && ($this->epn["Query"])) {
		$this->epn["ErrorMessage"] .= str_replace("%%keywords%%", $this->epn["Keywords"], PBL_ERROR_NO_RESULTS) . "<br />\r\n";
		$this->epn["Error"] = true;
	}
	if ((!empty($this->xml)) && (strlen($this->xml->channel->item[0]->title) == 0)) {
		$this->epn["ErrorMessage"] .= str_replace("%%keywords%%", $this->epn["Keywords"], PBL_ERROR_NO_RESULTS) . "<br />\r\n";
		$this->epn["Error"] = true;
	}
	if ($this->epn["CURL_Error"]) {
		$this->epn["Error"] = true;
		$this->epn["ErrorMessage"] .= $this->epn["CURL_ErrorMessage"] . "<br />\r\n";
		$this->epn["CURL_Error"] = false;
		$this->epn["CURL_ErrorMessage"] = "";
	}
	if ($this->epn["Error"]) {
		$this->epn["template"] = $this->LoadTemplate($this->path["error_url"]);
		$this->epn["template"] = str_replace("%%Error%%", $this->epn["ErrorMessage"], $this->epn["template"]);
		$this->epn["template"] = str_replace("%%Warning%%", $this->epn["Warning"], $this->epn["template"]);
		if ($this->epn["Item"] > "") {
			$this->epn["Text"] = str_replace($this->epn["Item"], $this->epn["template"], $this->epn["Text"]);
		} else {
			$this->epn["Text"] = $this->epn["template"];
		}
		return true;
	} else {
		return false;
	}
}

##################################################################################################

function GetDomain() {
	switch($this->epn["SiteID"]) {
		case "1":
			return "ebay.com";
		case "2":
			return "ebay.ie";
		case "3":
			return "ebay.at";
		case "4":
			return "ebay.com.au";
		case "5":
			return "benl.ebay.be";
		case "7":
			return "ebay.ca";
		case "10":
			return "ebay.fr";
		case "11":
			return "ebay.de";
		case "12":
			return "ebay.it";
		case "13":
			return "ebay.es";
		case "14":
			return "ebay.ch";
		case "15":
			return "ebay.co.uk";
		case "16":
			return "ebay.nl";
	}
}

##################################################################################################

function ParseQueryResults() {
	$this->epn["Count"] = 0;
	$this->epn["Result"] = "";
	$this->epn["FinalResult"] = "";
	foreach($this->xml->channel->item as $this->epn["Result"]){
		$pbl_request = array();
		$pbl_request["link"] = $this->epn["Result"]->link;
		$pbl_request["title"] = $this->epn["Result"]->title;
		$pbl_request["item"] = $this->epn["Result"]->guid;
		$pbl_request["EekStatus"] = $this->epn["Result"]->EekStatus[0];
		# check EEK Status for DE
		if ($pbl_request["EekStatus"] > "") {
			$pbl_request["EekStatus"] = "EEK:  " . $this->epn["Result"]->EekStatus . "</br>\r\n\t\t\t";
		} else {
			$pbl_request["EekStatus"] = "";
		}
		# clean up xml results
		$this->epn["Result"]->description = str_replace("<table border='0' cellpadding='8'>", '<table class="pbl-responsive">', $this->epn["Result"]->description);
		$this->epn["Result"]->description = str_replace(" <tr><td> ", "\r\n\t<tr>\r\n\t\t<td>\r\n\t\t\t", $this->epn["Result"]->description);
		$this->epn["Result"]->description = str_replace("</td></tr> </table>", "\r\n\t\t</td>\r\n\t</tr>\r\n</table>", $this->epn["Result"]->description);


		$this->epn["Result"]->description = str_replace("</td><td>", "\r\n\t\t</td>\r\n\t\t<td>\r\n\t\t\t" . $this->epn["Result"]->title . "</br>\r\n\t\t\t" . $pbl_request["EekStatus"], $this->epn["Result"]->description);
		$this->epn["Result"]->description = str_replace("<br>", "<br>\r\n\t\t\t", $this->epn["Result"]->description);
		$pos = strpos($this->epn["Result"]->description, "<td>");
		$pos = strpos($this->epn["Result"]->description, "<td>");
		if ($pos !== false) {
			$this->epn["Result"]->description = substr_replace($this->epn["Result"]->description, '<td>', $pos, strlen("<td>"));
		}
		$pos = strpos($this->epn["Result"]->description, "<td>");
		if ($pos !== false) {
			$this->epn["Result"]->description = substr_replace($this->epn["Result"]->description, '<td>', $pos, strlen("<td>"));
		}
		# if using SkimLinks, setup Skimlink affiliate URL
		if ($this->settings["SkimLinks"]) {
			preg_match_all('/(?<=href=\')(.*?)(?=\')/', $this->epn["Result"]->description, $match);
			$pbl_request["link_watch"] = $match[0][count($match[0])-1];
			$pbl_request["domain"] = $this->GetDomain();
			$pbl_request["url"] = "http://go.redirectingat.com?id=" . $pbl_options["SkimLinksID"] . "&xs=1&url=";
			$this->epn["Result"]->description = str_replace($pbl_request["link"], $pbl_request["url"] . urlencode("http://www." . $pbl_request["domain"] . "/itm/" . $pbl_request["title"] . "/" . $pbl_request["item"]), $this->epn["Result"]->description);
			$this->epn["Result"]->description = str_replace($pbl_request["link_watch"], $pbl_request["url"] . urlencode("http://cgi1." . $pbl_request["domain"] . "/ws/eBayISAPI.dll?MfcISAPICommand=MakeTrack&item=" . $pbl_request["item"]), $this->epn["Result"]->description);
		}
		if ($this->settings["VigLinks"]) {
			preg_match_all('/(?<=href=\')(.*?)(?=\')/', $this->epn["Result"]->description, $match);
			$pbl_request["link_watch"] = $match[0][count($match[0])-1];
			$pbl_request["domain"] = $this->GetDomain();
			# link for normal Ebay item listing
			$pbl_request["url"] = "http://cdn.viglink.com/api/click?format=text&key=" . urlencode($pbl_options["VigLinksID"]) . "&loc=" . urlencode($_SERVER["HTTP_REFERER"]) . "&out=";
			$this->epn["Result"]->description = str_replace($pbl_request["link"], $pbl_request["url"] . urlencode("http://www." . $pbl_request["domain"] . "/itm/" . $pbl_request["title"] . "/" . $pbl_request["item"]), $this->epn["Result"]->description);
			# link for item watch list
			$pbl_request["url"] = "http://api.viglink.com/api/click?key=" . urlencode($pbl_options["VigLinksID"]) . "&loc=" . urlencode($_SERVER["HTTP_REFERER"]) . "&out=";
			$this->epn["Result"]->description = str_replace($pbl_request["link_watch"], $pbl_request["url"] . urlencode("http://cgi1." . $pbl_request["domain"] . "/ws/eBayISAPI.dll?MfcISAPICommand=MakeTrack&item=" . $pbl_request["item"]), $this->epn["Result"]->description);
		}
		$this->epn["FinalResult"] .= $this->epn["Result"]->description . "\r\n";
		$this->epn["Count"]++;
		if ($this->epn["Count"] >= $this->epn["NumListings"]){break;}
	}
}

##################################################################################################

function ShortCode($atts, $issidebar=false) {
	if(isset($atts["debug"])){if (strtolower($atts["debug"]) == "true"){error_reporting(E_ALL & ~E_NOTICE);}}
	$this->epn = array();
    $this->GetSettings();
	if ($this->settings["MasterDisable"] == "1"){return;}
	$this->GetShortCode($atts);
    $this->DefineErrors();
    $this->SetPaths();
	$this->BuildQuery();
	if ($this->CheckForErrors()) {return $this->epn["Text"];}
	$this->ExecQuery();
	if ($this->CheckForErrors()) {
		return $this->epn["Text"];
	}
	$this->ParseQueryResults();
	return $this->epn["FinalResult"];
}
}#end ebay class
?>