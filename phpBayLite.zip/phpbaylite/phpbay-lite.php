<?php
/*
Plugin Name:  phpBay Lite for Wordpress
Plugin URI:   http://www.phpbay.com/phpbay-lite-wordpress-plugin.html
Description:  Monetize your Wordpress blog with Ebay auction listings using your Ebay Partner Network account.
Version:      2.0.0
Author:       phpbay.com
Author URI:   http://www.phpbay.com/

*/
define("PBL_VERSION", "2.0.0");
if (!defined("DS")) {define("DS", DIRECTORY_SEPARATOR);}
if (!defined("PBL_PLUGIN_DIR")){define("PBL_PLUGIN_DIR", dirname(__FILE__) . DS);}
if (!defined("PBL_PLUGIN_URL")){define("PBL_PLUGIN_URL", plugin_dir_url(__FILE__));}
#################################################
function phpbaylite_admin_panel() {
	$pbl_options = array();
	$pbl_temp = get_option("pbl_options");
	if (!empty($pbl_temp)) {
		foreach ($pbl_temp as $key => $option) {
			$pbl_options[$key] = $option;
		}
	}
	unset($pbl_temp);
	# Update Options if Changed and Submitted by Admin level User
	$getpost = $_POST;
	if ((isset ($getpost["PBL_updated"])) && (is_admin())) {
		# prevent sql injection attacks by escaping all data in $getpost array
		$getpost = array_map('htmlentities', $getpost);
		$getpost = array_map('stripslashes', $getpost);
		$getpost = array_map('trim', $getpost);
		# Get updated/set values
		$pbl_options["CampaignID"] = $getpost["PBL_campaignid"];
		$pbl_options["CustomID"] = $getpost["PBL_customid"];
		$pbl_options["MasterDisable"] = $getpost["PBL_MasterDisable"];
		$pbl_options["SiteId"] = $getpost["PBL_siteId"];
		$pbl_options["SkimLinks"] = $getpost["PBL_SkimLinks"];
		$pbl_options["SkimLinksID"] = $getpost["PBL_SkimLinksID"];
		$pbl_options["VigLinks"] = $getpost["PBL_VigLinks"];
		$pbl_options["VigLinksID"] = $getpost["PBL_VigLinksID"];
		# Update assigned values
		update_option("pbl_options", $pbl_options);

		# Display message that options are updated
		echo '<div id="message" class="updated fade"><p>phpBay Lite options saved.</p></div>';
		# Display message if Tag or ID are missing
		if (($pbl_options["CampaignID"] == "") && ($pbl_options["SkimLinks"] == "" && $pbl_options["SkimLinks"] == "")) {
			echo '<div id="message" class="updated fade error"><p>To display Ebay listings, enter your Campaign ID.</p></div>';}
	}
?>
	<div class="wrap">
    	<h2>phpBay Lite v<?php echo PBL_VERSION;?> Dashboard</h2>
		<form name="phpbay-lite" id="phpbay-lite" method="post">
		<div id="tabs">
			<ul>
				<li><a href="#tabs-1">Affiliate Settings</a></li>
				<li><a href="#tabs-2">Upgrade to Pro</a></li>
			</ul>
			<div id="tabs-1">
			<fieldset class="options">
				<legend><h2>Ebay Affiliate Settings</h2></legend>

				<p><label><strong><a href="https://www.ebaypartnernetwork.com" target="_blank">Ebay Campaign ID</a>:</strong> &nbsp;&nbsp;</label>
					<input name="PBL_campaignid" type="text" value="<?php echo $pbl_options["CampaignID"]; ?>" maxlength="40">
					<img class="tooltip" src="<?php echo PBL_PLUGIN_URL . '/media/img/help.png'?>" title="The Campaign ID is generated in your Ebay Partner Network (EPN) account.  Each site you add to your account, Ebay will generate a Custom ID for it.  Place that Custom ID in this box.  This field is required.  Without a numerical value in this field, Ebay's RSS2 server will reject the request and no results will be returned.  If you do not yet have an EPN account, you can use a ficticious number, but it must be all numbers.  For example, if you do not have an EPN account yet, you could enter: 123456789" align="absmiddle"/>
                </p>

				<p><label><strong>Custom ID:</strong> &nbsp;&nbsp;</label>
					<input name="PBL_customid" type="text" value="<?php echo $pbl_options["CustomID"]; ?>" maxlength="40">
					<img class="tooltip" src="<?php echo PBL_PLUGIN_URL . '/media/img/help.png'?>" title="A custom ID is a way to track conversions in your Ebay Parner Network account.  This is an optional setting and not required, but can be useful to help track specific sites to see who much of your overall earnings are being generated from the particular site.  Use underscores for spaces.  A custom_id might look like: archery_bear_youth_bow" align="absmiddle"/>
                </p>

				<p><input name="PBL_SkimLinks" id="PBL_SkimLinks" type="checkbox" value="1" <?php if ($pbl_options["SkimLinks"] == "1") {echo "checked";}?> />&nbsp;&nbsp;<label>Use <a href="http://go.skimlinks.com/?id=16768x737555&xs=1&url=http://skimlinks.com" target="_blank" title="Skimlinks Simplified Afiliate Marketing">Skimlinks</a> Service</label>
					<img class="tooltip" src="<?php echo PBL_PLUGIN_URL . '/media/img/help.png'?>" title="Skimlinks helps you monetize online content by converting product links into their equivalent affiliate links so you can earn a commission effortlessly every time a purchase is made." align="absmiddle"/>
        		</p>

				<p><label><strong>Skimlinks Publisher ID:</strong> &nbsp;&nbsp;</label>
					<input name="PBL_SkimLinksID" type="text" value="<?php echo $pbl_options["SkimLinksID"]; ?>" maxlength="40" />
        		</p>

				<p><input name="PBL_VigLinks" id="PBL_VigLinks" type="checkbox" value="1" <?php if ($pbl_options["VigLinks"] == "1") {echo "checked";}?> />&nbsp;&nbsp;<label>Use <a href="http://www.viglink.com/?vgref=85268" target="_blank" title="Viglink Affliate Network">Viglink</a> Service</label>
					<img class="tooltip" src="<?php echo PBL_PLUGIN_URL . '/media/img/help.png'?>" title="Viglinks does not require that a user have an EPN account.  If your EPN account is suspended or you cannot get into EPN, you can try signing up for Viglinks." align="absmiddle"/>
        		</p>

				<p><label><strong>Viglinks API Key:</strong> &nbsp;&nbsp;</label>
					<input name="PBL_VigLinksID" type="text" value="<?php echo $pbl_options["VigLinksID"]; ?>" maxlength="40" />
        		</p>

				<p><label><strong>Default Country:</strong> &nbsp;&nbsp;</label>
					<select name="PBL_siteId" id="PBL_siteId">
						<option value="1"<?php if ($pbl_options["SiteID"] == "1") {echo " selected";}?>>United States</option>
						<option value="4"<?php if ($pbl_options["SiteID"] == "4") {echo " selected";}?>>Australia</option>
						<option value="3"<?php if ($pbl_options["SiteID"] == "3") {echo " selected";}?>>Austria</option>
						<option value="5"<?php if ($pbl_options["SiteID"] == "5") {echo " selected";}?>>Belgium</option>
						<option value="7"<?php if ($pbl_options["SiteID"] == "7") {echo " selected";}?>>Canada</option>
						<option value="10"<?php if ($pbl_options["SiteID"] == "10") {echo " selected";}?>>France</option>
						<option value="11"<?php if ($pbl_options["SiteID"] == "11") {echo " selected";}?>>Germany</option>
						<option value="2"<?php if ($pbl_options["SiteID"] == "2") {echo " selected";}?>>Ireland</option>
						<option value="12"<?php if ($pbl_options["SiteID"] == "12") {echo " selected";}?>>Italy</option>
						<option value="16"<?php if ($pbl_options["SiteID"] == "16") {echo " selected";}?>>Netherlands</option>
						<option value="13"<?php if ($pbl_options["SiteID"] == "13") {echo " selected";}?>>Spain</option>
						<option value="14"<?php if ($pbl_options["SiteID"] == "14") {echo " selected";}?>>Switzerland</option>
						<option value="15"<?php if ($pbl_options["SiteID"] == "15") {echo " selected";}?>>United Kingdom</option>
					</select>
					<img class="tooltip" src="<?php echo PBL_PLUGIN_URL . '/media/img/help.png'?>" title="Select the country your site will be targeting." align="absmiddle"/>
                </p>

				<p><input name="PBL_MasterDisable" id="PBL_MasterDisable" type="checkbox" value="1" <?php if ($pbl_options["MasterDisable"] == "1") {echo "checked";}?>>&nbsp;&nbsp;<label>Emergency.  Disable all Ebay queries from phpBay Lite</label>
                	<img class="tooltip" src="<?php echo PBL_PLUGIN_URL . '/media/img/help.png'?>" title="Over the years, there have been a few times where Ebay's RSS/RSS2 server has been offline for a few hours, up to a few days.  It's rare, but when this happens, your site will continue to make requests to Ebay's RSS2 server, which can severely impact performance when their server is down.  This an emergency setting that will temporarily disalbe all Ebay queries to their RSS2 server, so as not to impact your site's performance should their server go down." align="absmiddle"/>
                </p>

				<input type="hidden" name="PBL_updated" value="1">
        		<p class="submit"><input class="button-primary" type="submit" name="Submit" value="Update &raquo;" /></p>

			</fieldset>



            	
            </div>
			<div id="tabs-2">

		<!-- pricing table -->
		<div class="p_table">
		
			<!-- caption column -->
			<div class="caption_column">
				<ul>
					<!-- column header -->
					<li class="header_row_1 align_center radius5_topleft"></li>
					<li class="header_row_2"><h2 class="caption"><span>upgrade</span> options</h2></li>
					<!-- data rows -->
					<li class="row_style_4"><span>Keyword Search</span></li>
					<li class="row_style_2"><span>All EPN Countries</span></li>
					<li class="row_style_4"><span>All EPN Sorting Options</span></li>
					<li class="row_style_2"><span>Custom Tracking IDs</span></li>
					<li class="row_style_4"><span>Support for SkimLinks</span></li>
					<li class="row_style_2"><span>Support for Viglinks</span></li>
					<li class="row_style_4"><span>SEO Urls</span></li>
					<li class="row_style_2"><span>Custom Templates</span></li>
					<li class="row_style_4"><span>Pagination for items</span></li>
					<li class="row_style_2"><span>List items in row or column</span></li>
					<li class="row_style_4"><span>List items from Ebay Store</span></li>
					<li class="row_style_2"><span>List items by seller id</span></li>
					<li class="row_style_4"><span>Custom Sidebar Widget</span></li>
					<li class="row_style_2"><span>Extended Shortcodes</span></li>
					<li class="row_style_4"><span>Extensive user manual</span></li>
					<li class="row_style_2"><span>Access to Support Forums</span></li>
					<li class="row_style_4"><span>Includes Amazon Plugin</span></li>
					<!-- column footer -->
					<li class="footer_row"></li>
				</ul>
			</div>
			
			<!-- column style 1 -->
			<div class="column_1">
				<!-- uncomment line below to display ribbon -->
				<!--<div class="column_ribbon">Label</div>-->
				<!-- /ribbon -->
				
				<ul>
					<!-- column header -->
					<li class="header_row_1 align_center"><h2 class="col1">phpBay Lite</h2></li>
					<li class="header_row_2 align_center"><h1 class="col1">$<span>Free</span></h1></li>
					<!-- data rows -->
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<li class="row_style_1 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<li class="row_style_3 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<li class="row_style_1 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<li class="row_style_3 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<li class="row_style_1 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<li class="row_style_3 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<li class="row_style_1 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<li class="row_style_3 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<li class="row_style_1 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<li class="row_style_3 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<!-- column footer -->
					<li class="footer_row"><a href="" class="sign_up radius3">Installed</a></li>
				</ul>
			</div>
			
			<!-- column style 2 -->
			<div class="column_2">
				<!-- uncomment line below to display ribbon -->
				<!--<div class="column_ribbon">Label</div>-->
				<!-- /ribbon -->
				
				<ul>
					<!-- column header -->
					<li class="header_row_1 align_center"><h2 class="col2">phpBay Pro</h2></li>
					<li class="header_row_2 align_center"><h1 class="col2">$<span>79</span></h1><h3 class="col2">Ebay</h3></li>
					<!-- data rows -->
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_1 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_3 align_center icon-no-2"><span><span class="hidden_caption_span">Icons Style 2</span></span></li>
					<!-- column footer -->
					<li class="footer_row"><a href="http://www.phpbay.com/" class="sign_up radius3">Upgrade</a></li>
				</ul>
			</div>
			
			<!-- column style 3 -->
			<div class="column_3">
				<!-- uncomment line below to display ribbon -->
				<!--<div class="column_ribbon">Label</div>-->
				<!-- /ribbon -->
				
				<ul>
					<!-- column header -->
					<li class="header_row_1 align_center"><h2 class="col3">Pro Bundle</h2></li>
					<li class="header_row_2 align_center"><h1 class="col3">$<span>99</span></h1><h3 class="col2">Ebay & Amazon</h3></li>
					<!-- data rows -->
					<li class="row_style_4 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_2 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_4 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_2 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_4 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_2 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_4 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_2 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_4 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_2 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_4 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_2 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_4 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_2 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_4 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_2 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<li class="row_style_4 align_center icon-yes-1"><span><span class="hidden_caption_span">Icons Style 1</span></span></li>
					<!-- column footer -->
					<li class="footer_row"><a href="http://www.phpbay.com/" class="sign_up radius3">Upgrade</a></li>
				</ul>
			</div>
			
			
		</div>	
		


		</div>
	</form>
	</div> <!-- .wrap -->
<?php
}
# end PBL_admin_panel
##################################################################################################
# Main phpBay Lite Class Here
##################################################################################################
$pbl_options = array();
$pbl_temp = get_option("pbl_options");
if (!empty($pbl_temp)) {
	foreach ($pbl_temp as $key => $option) {
		$pbl_options[$key] = $option;
	}
}
unset($pbl_temp);
?>
<script type='text/javascript'>
var pbl_plugin = {
    'siteid': '<?php echo $pbl_options["siteId"];?>',
};
</script>
<?php
require_once(dirname(__FILE__) . "/ebay.php");
##################################################################################################
function pbl_genString($length = ""){
	$code = md5(uniqid(rand(), true));
	if ($length != ""){return "pbl_" . substr($code, 0, $length);} else {return "pbl_" . $code;}
}
##################################################################################################
function phpbaylite_shortcode($atts) {
//echo "inside phpbaylite_shortcode function";
//exit;
	$phpBayLite = new phpBayLite();
	$text = $phpBayLite->ShortCode($atts, false);
	return $text;
//return "inside phpbaylite_shortcode function";
//echo "inside phpbaylite_shortcode function";
//exit;
}
##################################################################################################
function phpbaylite_init(){
	//if (!is_admin()) {return;}
	if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {return;}
	if (get_user_option('rich_editing') == "true") {
		add_filter("mce_external_plugins", "add_phpbaylite_tinymce_plugin");
		add_filter("mce_buttons", "register_phpbaylite_button");
	}
}
#################################################
function register_phpbaylite_button($buttons) {
	if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {return;}
	array_push($buttons, "|", "phpBayLite");
	return $buttons;
}
#################################################
function add_phpbaylite_tinymce_plugin($plugin_array) {
	if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {return;}
	$plugin_array["phpBayLite"] = PBL_PLUGIN_URL . "tinymce/editor_plugin.js";
	return $plugin_array;
}
#################################################
function phpbaylite_admin_init() {
	wp_register_script("phpbay-lite-admin-js", PBL_PLUGIN_URL . "media/js/admin.js", __FILE__ );
}
#################################################
function phpbaylite_admin_menu(){
	if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {return;}
	global $pbl_options_page;
	if (function_exists("add_options_page")) {
		$pbl_options_page = add_menu_page( 'phpBay Lite Settings Dashboard', 'phpBay Lite', 'manage_options', 'phpbay-lite-plugin', 'phpbaylite_admin_panel' );
	}
}
#################################################
function phpbaylite_admin_print_scripts($hook) {
	global $pbl_options_page;
	global $pbl_options;
	if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {return;}
	if ($hook != $pbl_options_page) {return;}
	# admin css styles
	wp_enqueue_style("phpbay-lite-admin-css", PBL_PLUGIN_URL . "media/css/admin.css", "", "", "all");
	wp_enqueue_script("jquery");
	wp_enqueue_script("jquery-core");
	wp_enqueue_script ('jquery-ui-tabs');
	wp_enqueue_script ('jquery-ui-tooltip');
	wp_enqueue_style("phpbay-lite-admin-ui-css","http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/start/jquery-ui.css", false, "1.11.2", false);
	wp_enqueue_script("phpbay-lite-admin-js");
}
#################################################
function phpbaylite_settings_link($actions, $file) {
	if (false !== strpos($file, "phpbay-lite")) {
		$actions['settings'] = '<a href="options-general.php?page=phpbay-lite-plugin">Settings</a>';
	}
	return $actions; 
}
#################################################
function phpbaylite_go_pro_link($actions, $file) {
	if (plugin_basename(__FILE__) == $file) {
		$actions[] = sprintf('&#9658; <a href="%s">%s</a>','http://www.phpbay.com/store/signup.php',__( 'Go Pro', 'plugin_action_links' ));
	}
	return $actions;
}
#################################################
function phpbaylite_wp_head_print_scripts() {
	if (is_admin()) {return;}
	//wp_enqueue_script(pbl_genString(6)."-js", PBL_PLUGIN_URL . "media/js/responsive-tables.js");
}
#################################################
function phpbaylite_wp_head_print_styles() {
	if (is_admin()) {return;}
	wp_enqueue_style(pbl_genString(6), PBL_PLUGIN_URL . "media/css/style.css", "", "", "all");
}
#################################################
error_reporting(E_ERROR);
add_action("init", "phpbaylite_init");
add_shortcode("phpbaylite", "phpbaylite_shortcode");
add_filter("plugin_action_links", "phpbaylite_settings_link", 2, 2);
add_filter( 'plugin_row_meta', "phpbaylite_go_pro_link", 10, 2 );
add_action("admin_menu", "phpbaylite_admin_menu");
add_action ("admin_init", "phpbaylite_admin_init");
add_action("admin_enqueue_scripts", "phpbaylite_admin_print_scripts");
add_action("wp_print_scripts", "phpbaylite_wp_head_print_scripts");
add_action("wp_print_styles", "phpbaylite_wp_head_print_styles");
//echo "inside phpbay-lite.php -> after add_filters";
//exit;
?>
