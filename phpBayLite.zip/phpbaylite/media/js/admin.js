// JavaScript Document
jQuery(document).ready(function($){
	$("#tabs").tabs();
	$(".tooltip[title]").tooltip({
		position: { my: "left+45 top-35" }
	});
});
