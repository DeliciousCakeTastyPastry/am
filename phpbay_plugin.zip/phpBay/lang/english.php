<?php
# For language translation, DO NOT change the %%variables%% names.  These are using within the main
# program.  Only change text values NOT within %% tags.
###################################
#           JQUERY TABS           #
###################################
define("PB_TAB_AFFILIATE", "Affiliate Settings");
define("PB_TAB_SETTINGS", "Settings");
define("PB_TAB_LEGACY", "Legacy");
define("PB_TAB_PAGING", "Paging Options");
define("PB_TAB_SEO", "SEO Options");
define("PB_TAB_HTACCESS", ".htaccess Code");
define("PB_TAB_RESOURCES", "Resources");
###################################
#      JQUERY TAB - AFFILIATE     #
###################################
define("PB_AFFILIATE_TITLE", "Ebay Affiliate Settings");
define("PB_AFFILIATE_KEY", "License Key");
define("PB_AFFILIATE_LICENSE_ACTIVE", "License is Active");
define("PB_AFFILIATE_CAMPAIGN_ID", "Ebay Campaign ID");
define("PB_AFFILIATE_CUSTOM_ID", "Custom ID");
define("PB_AFFILIATE_DEFAULT_COUNTRY", "Default Country");
define("PB_AFFILIATE_DEFAULT_LANGUAGE", "Default Language");
define("PB_AFFILIATE_SKIM_LINKS", 'Use <a href="http://go.skimlinks.com/?id=16768x737555&xs=1&url=http://skimlinks.com" target="_blank" title="Skimlinks Simplified Afiliate Marketing">Skimlinks</a> Service');
define("PB_AFFILIATE_SKIM_LINKS_PUBLISHER_ID", 'Skimlinks Publisher ID');
define("PB_AFFILIATE_MASTER_DISABLE", 'Emergency.  Disable all Ebay queries from phpBay Pro');
define("PB_AFFILIATE_CATEGORY_DISABLE", 'Emergency.  Disable all categories from Ebay queries from phpBay Pro');
define("PB_AFFILIATE_VIG_LINKS", 'Use <a href="http://www.viglink.com/?vgref=85268" target="_blank" title="Viglink Affliate Network">Viglink</a> Service');
define("PB_AFFILIATE_VIG_LINKS_PUBLISHER_ID", 'Viglinks API Key');
###################################
#       JQUERY TAB - OPTIONS      #
###################################
define("PB_OPTIONS_TITLE", "phpBay Pro Options");
define("PB_OPTIONS_SORT", "Display Sort Options");
define("PB_OPTIONS_LOGO", "Display Ebay Logo");
define("PB_OPTIONS_LOGO_SIDEBAR", "Display Ebay Logo on Sidebar");
define("PB_OPTIONS_GEO", "Enable GEO IP Targeting");
define("PB_OPTIONS_AVAILABLE_TO", "Country Items Are Available To");
define("PB_OPTIONS_LOCATED_IN", "Country Items Are Located In");
define("PB_OPTIONS_EBAY_LINK", "Display Link to Ebay Category");
define("PB_OPTIONS_REMOVE_DUPLICATES", "Remove Duplicate Listings");
define("PB_OPTIONS_DATE_TYPE", "Display Date as: ");
define("PB_OPTIONS_END_DATE", "End Date");
define("PB_OPTIONS_TIME_REMAINING", "Time Remaining");
define("PB_OPTIONS_BIN_LINK", "Display Buy It Now Link");
define("PB_OPTIONS_BID_LINK", "Display Bid Link");
define("PB_OPTIONS_WATCH_LINK", "Display Add to Watchlist Link");
define("PB_OPTIONS_CLEAN_TITLES", "Create Clean Product Titles");
###################################
#   JQUERY TAB - OPTIONS TOOLTIP  #
###################################
define("PB_TOOLTIP_SORT", "Displays a drop down menu for sorting results on each auction listing.  Recommended setting.");
define("PB_TOOLTIP_LOGO", "Display the Ebay logo with auction listings.  Recommended setting.");
define("PB_TOOLTIP_LOGO_SIDEBAR", "Display the Ebay logo on the Sidebar.");
define("PB_TOOLTIP_GEO", "Use GEO IP Targeting with free Maxmind country database (already built-in).  Recommended setting.");
define("PB_TOOLTIP_AVAILABLE_TO", "Works in conjunction with GEO IP Targeting, to show products available TO a user's country according to their IP address.");
define("PB_TOOLTIP_LOCATED_IN", "Works in conjunction with GEO IP Targeting, to show products located IN a user's country according to their IP address.");
define("PB_TOOLTIP_EBAY_LINK", "Displays a link to Ebay for more results, under auction list, IF (This is important!) a category is set in the [phpbay] tag.  Recommended setting.");
define("PB_TOOLTIP_SKIM_LINKS", "Skimlinks helps you monetize online content by converting product links into their equivalent affiliate links so you can earn a commission effortlessly every time a purchase is made.");
define("PB_TOOLTIP_VIG_LINKS", "Viglinks does not require that a user have an EPN account.  If your EPN account is suspended or you cannot get into EPN, you can try signing up for Viglinks.");
define("PB_TOOLTIP_MASTER_DISABLE", "Should a problem arrise with EPN's RSS2 query server, check this box to disable phpBay Pro from making any queries to Ebay.  This is an emergency setting.");
define("PB_TOOLTIP_CATEGORY_DISABLE", "Disable all categories from being passed in the Ebay query.  This is an emergency setting.");
define("PB_TOOLTIP_REMOVE_DUPLICATES", "Remove duplicate auction listings.  Scans titles from returned results to ensure only one of each is displayed.");
define("PB_TOOLTIP_DATE_TYPE", "Display auction date as Time Remaining or End Date.");
define("PB_TOOLTIP_CLEAN_TITLES", "Improves Product Titles by removing unnecessary characters used to draw attention.");
define("PB_TOOLTIP_BIN_LINK", "Display a link to Buy It Now on Ebay, if the product has a BIN.");
define("PB_TOOLTIP_BID_LINK", "Display a link to Bid Now on Ebay, if the product has a BIN.");
define("PB_TOOLTIP_WATCH_LINK", "Display a link to add a product to a user's Watch List on Ebay.");
define("PB_TOOLTIP_SEO_URL_PREFIX", "This is very important!  The htaccess code uses this value when using SEO URLs feature.  If you change the url prefix, you MUST update your htaccess file or your links will not work correctly.");
define("PB_TOOLTIP_STEALTH_URLS", "The Stealth URLs extension will only work if SEO URLs are enabled.");
###################################
#        JQUERY TAB - LEGACY      #
###################################
define("PB_LEGACY_OPTIONS", "Legacy Options");
define("PB_LEGACY_OPTIONS_TEXT", 'Legacy Global settings prior to 4.0 (if upgrading).  It is best not to use these with new sites, as the popup menus allow for broader customization.');
define("PB_LEGACY_DISPLAY_COLUMNS", "Display results in columns?");
define("PB_LEGACY_DISPLAY_COLUMNS_NUM", "Number of columns to use");
define("PB_LEGACY_COLUMNS_SELECT", "Select Number of Columns");
define("PB_LEGACY_COLUMNS_DISABLE", "Disable (Off)");
define("PB_LEGACY_POSTAL_CODE", "Zip or Postal Code");
define("PB_LEGACY_MAX_DISTANCE", "Max Distance from Postal Code");
define("PB_LEGACY_SORT_DEFAULT", "Default Sorting");
define("PB_LEGACY_SORT_SELECT", "Select Default Sort");
define("PB_LEGACY_SORT_DISABLE", "Disable (Off)");
define("PB_LEGACY_MIN_PRICE", "Minimum Price");
define("PB_LEGACY_MAX_PRICE", "Maximum Price");
define("PB_LEGACY_SELLER_ID", "Specific Seller ID");
define("PB_LEGACY_PAGING", "Use Paging");
define("PB_LEGACY_BIN", "Display 'Buy it Now' Items Only");
define("PB_LEGACY_ITEMS_PER_PAGE", "Set max listings per page");
define("PB_LEGACY_FREE_SHIPPING", "Display Items with Free Shipping Only");
###################################
#        JQUERY TAB - PAGING      #
###################################
define("PB_PAGING_OPTIONS", "Paging Options");
define("PB_PAGING_OPTIONS_TEXT", 'Select the default pagination (paging) style:');
###################################
#         JQUERY TAB - SEO        #
###################################
define("PB_SEO_TITLE", "SEO Options");
define("PB_SEO_MOD_REWRITE", "Use mod_rewrite on Ebay Images?");
define("PB_SEO_STEALTH", "Use jQuery Stealth Mod URLs");
define("PB_SEO_URLS", "SEO URLs");
define("PB_SEO_URLS_USE", "Use SEO URLS");
define("PB_SEO_DEFAULT_URLS", "Default Ebay URLs");
define("PB_SEO_URL_PREFIX", "URL Prefix: ");
###################################
#      JQUERY TAB - HTACCESS      #
###################################
define("PB_HTACCESS_TITLE", ".htaccess Code");
define("PB_HTACCESS_TEXT", "The following code should go in your .htaccess file, above any Wordpress code in the .htaccess file:");
define("PB_HTACCESS_ERROR", "Based on the settings in the SEO Options Tab, there is no .htaccess code to generate.  If you have selected SEO URLs and/or mod_rewrite images, click on the <font color='red'><strong>Update Options</strong></font> button located in the SEO Options Tab, then come back to this tab for the .htaccess code.");
###################################
#      JQUERY TAB - RESOURCES     #
###################################
define("PB_RESOURCES_TITLE", "Helpful Resources");
###################################
#            MISC PLUGIN          #
###################################
define("PB_SMALL", "Small");
define("PB_MEDIUM", "Medium");
define("PB_LARGE", "Large");
define("PB_OPTIONS_SAVED", "phpBay Pro options saved.");
define("PB_UPDATE_OPTIONS", "Update Options");
define("PB_RECOMMENDED", "Select Recommended");
# Minimum folder permission needed to read/write/execute for all groups.
# Generally this is "0777".  On suPHP, this may be "0755".
define("PB_CHMOD_MIN_FOLDER_PERMISSION", "0777");
# Minimum file permission needed to store cache files to your server.
# Generally this is "0644".  When cache files are written, they are chmod to this value.
define("PB_CHMOD_MIN_FILE_PERMISSION", "0644");
# Minimum file permission needed for the script to delete cache files.
# Generally this is "0777".  On suPHP, this may be "0755".
define("PB_CHMOD_MIN_DELETE_FILE_PERMISSION", "0777");
###################################
#           POPUP MENUS           #
###################################
define("PB_POPUP_SEARCH_TITLE", "phpBay Pro - Search Options");
define("PB_POPUP_SEARCH_OPTIONS_TITLE", "Options for phpBay Pro Product Search Results");
define("PB_POPUP_SEARCH_KEYWORD", "Keyword(s):");
define("PB_POPUP_SEARCH_COUNTRY", "Country:");
define("PB_POPUP_SEARCH_NUMBER", "Number of Results:");
define("PB_POPUP_SEARCH_CATEGORY", "Category (Optional):");
define("PB_POPUP_SEARCH_CUSTOM_ID", "Custom ID:");
define("PB_POPUP_SEARCH_SORT", "Sort Order:");
define("PB_POPUP_SEARCH_MIN", "Minimum Price:");
define("PB_POPUP_SEARCH_MAX", "Maximum Price:");
define("PB_POPUP_SEARCH_SELLERID", "Seller ID (Optional):");
define("PB_POPUP_SEARCH_FREE_SHIPPING", "Items w/Free Shipping");
define("PB_POPUP_SEARCH_TEMPLATE", "Template Name:");
define("PB_POPUP_SEARCH_COLUMNS", "Number of Columns:");
define("PB_POPUP_SEARCH_COLUMNS_SELECT", "Select Number of Columns");
define("PB_POPUP_SEARCH_PAGING", "Page results?");
define("PB_POPUP_SEARCH_PAGING_YES", "Yes");
define("PB_POPUP_SEARCH_PAGING_NO", "No");
define("PB_POPUP_SEARCH_GENERATE", "Generate");
define("PB_POPUP_SEARCH_ITEMS_PER_PAGE", "Items Per Page:");
define("PB_POPUP_SEARCH_ITEMS_PER_PAGE_SELECT", "Select Items Per Page");
###################################
#           POPUP MENUS           #
###################################
define("PB_POPUP_SHORTCODE_TITLE", "phpBay Pro - Shortcode List");
define("PB_POPUP_SHORTCODE_LEGEND", "List of Shortcodes for phpBay Pro");
###################################
#              WIDGET             #
###################################
define("PB_WIDGET_TITLE", "Title");
define("PB_WIDGET_INSTRUCTIONS", "This widget sets a global sidebar widget for phpBay Pro.  Ideally, you would set this to match the theme/niche of your site.  Within your Wordpress Pages and Posts, you can add a new widget that will override the global phpBay Pro widget, such that you can have a different sidebar widget on a per Page and per Post instance.");
define("PB_WIDGET_KEYWORDS", "Keywords");
define("PB_WIDGET_NUMBER", "Number of Results");
define("PB_WIDGET_CUSTOM_ID", "Custom ID");
define("PB_WIDGET_COUNTRY", "Country");
define("PB_WIDGET_CATEGORY", "Category");
define("PB_WIDGET_SORT", "Sort Order");
define("PB_WIDGET_PRICE_INSTRUCTIONS", "When setting a min/max price, do not use decimals.  For example, to display products priced between $25.00 and $75.00, MinPrice would be 25 and MaxPrice would be 75.");
define("PB_WIDGET_MINPRICE", "Minimum Price (optional)");
define("PB_WIDGET_MAXPRICE", "Maximum Price (optional)");
define("PB_WIDGET_MINBID", "Minimum Bids (optional)");
define("PB_WIDGET_MAXBID", "Maximum Bids (optional)");
define("PB_WIDGET_SELLER_ID", "Specific Seller ID");
define("PB_WIDGET_ERROR", "In order to use this feature, you must first activate and setup a global phpBay Pro Sidebar Widget.  To do this, go to your Wordpress Dashboard and select Appearance->Widgets in the left side menu.  Then add the phpBay Pro Sidebar Widget to one of your sidebars and setup the options.");
define("PB_WIDGET_PAGE_TITLE", "phpBay Pro - Sidebar Widget Options");
define("PB_WIDGET_PAGE_OPTIONS", "phpBay Pro - Sidebar Widget Options");
define("PB_WIDGET_OVERRIDE", "Replace existing Widget:");
define("PB_WIDGET_FREE_SHIPPING", "Items w/Free Shipping");
define("PB_WIDGET_HOME_PAGE", "Do not show on home page");
define("PB_WIDGET_LIST_TYPE", "Listing Type");
###################################
#          ERROR MESSAGES         #
###################################
define("PB_ERROR_CAMPAIGN_ID", "To display Ebay listings, enter your Campaign ID.");
define("PB_ERROR_KEYWORD", "To display Ebay results, you must first enter a keyword or keyword phrase.  Please consult the user manual.");
define("PB_ERROR_VERSION", "phpBay requires PHP version 5.0 or higher in order to execute functionality that is only available in versions higher than this.  Please consult with your webhost to upgrade your server's php version.");
define("PB_ERROR_SIMPLEXML", "phpBay requires the function 'simplexml_load_string' in order to function properly.  Please consult with your webhost to have this functionality installed.");
define("PB_ERROR_EBAY_XML", "Ebay has returned a malformed xml response.  This could be due to testing or a bug in the RSS2 Generator.  Please check the support forums to see if there are any posts regarding recent RSS2 Generator bugs.");
define("PB_ERROR_CURL", "phpBay requires the function 'curl_init' in order to function properly.  Please consult with your webhost to have this functionality installed.");
define("PB_ERROR_TEMPLATE", "The template specified at %%templatefolder%% does not exist.  Please check to be sure you have uploaded this template to your templates folder.");
define("PB_ERROR_COOKIE", "<font color='red'><strong>Cookies must be enabled for the login feature of the Admin dashboard.</strong></font>");
define("PB_ERROR_FILE", 'Please delete the file: ');
define("PB_ERROR_NO_RESULTS", 'No items matching the keyword phrase <u>"%%keywords%%"</u> were found.  This could be due to the keyword phrase used, or could mean your server is unable to communicate with Ebays RSS2 Server.');
###################################
#            TEMPLATES            #
###################################
define("PB_TEMP_PAGING_PREVIOUS", "Previous");
define("PB_TEMP_PAGING_NEXT", "Next");
define("PB_TEMP_MORE_BUTTON", '<img src="%%Path%%' . "details.gif" . '" alt="" border="0" />' . "<br />\r\n");
define("PB_TEMP_SEPERATOR", " | ");
define("PB_TEMP_PAGINATION_SEPERATOR", "<br />\r\n");
define("PB_TEMP_LINK", '<a href="%%Link%%" title="%%Title%%">%%Title%%</a>');
define("PB_TEMP_OPEN", "<div>\r\n");
define("PB_TEMP_CLOSE", "\r\n</div>\r\n");
define("PB_TEMP_PRODUCT_TRUNCATE_URL_NUM", 300);
define("PB_TEMP_EBAY_LOGO", '<img src="%%logo%%" alt="" border="0" width="100px" height="53px" />');
define("PB_TEMP_SIDEBAR_EBAY_LOGO", '<img src="%%logo%%" alt="" border="0" width="100px" height="53px" />');
define("PB_TEMP_ITEMS_PER_PAGE", 10);
###################################
#       LANGUAGE US               #
###################################
define("PB_TEMP_US_BID_NOW_LINK", "Bid now");
define("PB_TEMP_US_BIN_LINK", "Buy It Now");
define("PB_TEMP_US_ADD_LINK", "Add to watch list");
define("PB_TEMP_US_BIDS_TEXT", " (%%NumBids%% Bids)");
define("PB_TEMP_US_BIN_TEXT", "Buy It Now for only: ");
define("PB_TEMP_US_END_DATE_TEXT", "End Date: ");
define("PB_TEMP_US_TIME_REMAINING_TEXT", "Time Remaining: ");
###################################
#       LANGUAGE CA               #
###################################
define("PB_TEMP_CA_BID_NOW_LINK", "Bid now");
define("PB_TEMP_CA_BIN_LINK", "Buy It Now");
define("PB_TEMP_CA_ADD_LINK", "Add to watch list");
define("PB_TEMP_CA_BIDS_TEXT", " (%%NumBids%% Bids)");
define("PB_TEMP_CA_BIN_TEXT", "Buy It Now for only: ");
define("PB_TEMP_CA_END_DATE_TEXT", "End Date: ");
define("PB_TEMP_CA_TIME_REMAINING_TEXT", "Time Remaining: ");
###################################
#       LANGUAGE GB               #
###################################
define("PB_TEMP_GB_BID_NOW_LINK", "Bid now");
define("PB_TEMP_GB_BIN_LINK", "Buy It Now");
define("PB_TEMP_GB_ADD_LINK", "Add to watch list");
define("PB_TEMP_GB_BIDS_TEXT", " (%%NumBids%% Bids)");
define("PB_TEMP_GB_BIN_TEXT", "Buy It Now for only: ");
define("PB_TEMP_GB_END_DATE_TEXT", "End Date: ");
define("PB_TEMP_GB_TIME_REMAINING_TEXT", "Time Remaining: ");
###################################
#       LANGUAGE AU               #
###################################
define("PB_TEMP_AU_BID_NOW_LINK", "Bid now");
define("PB_TEMP_AU_BIN_LINK", "Buy It Now");
define("PB_TEMP_AU_ADD_LINK", "Add to watch list");
define("PB_TEMP_AU_BIDS_TEXT", " (%%NumBids%% Bids)");
define("PB_TEMP_AU_BIN_TEXT", "Buy It Now for only: ");
define("PB_TEMP_AU_END_DATE_TEXT", "End Date: ");
define("PB_TEMP_AU_TIME_REMAINING_TEXT", "Time Remaining: ");
###################################
#       LANGUAGE IE               #
###################################
define("PB_TEMP_IE_BID_NOW_LINK", "Bid now");
define("PB_TEMP_IE_BIN_LINK", "Buy It Now");
define("PB_TEMP_IE_ADD_LINK", "Add to watch list");
define("PB_TEMP_IE_BIDS_TEXT", " (%%NumBids%% Bids)");
define("PB_TEMP_IE_BIN_TEXT", "Buy It Now for only: ");
define("PB_TEMP_IE_END_DATE_TEXT", "End Date: ");
define("PB_TEMP_IE_TIME_REMAINING_TEXT", "Time Remaining: ");
###################################
#       LANGUAGE DE               #
###################################
define("PB_TEMP_DE_BID_NOW_LINK", "Jetzt bieten");
define("PB_TEMP_DE_BIN_LINK", "Sofort-Kaufen");
define("PB_TEMP_DE_ADD_LINK", "Zur Liste der beobachteten Artikel hinzufügen");
define("PB_TEMP_DE_BIDS_TEXT", " (%%NumBids%% Gebote)");
define("PB_TEMP_DE_BIN_TEXT", "Sofort-Kaufen für nur: ");
define("PB_TEMP_DE_END_DATE_TEXT", "Angebotsende: ");
define("PB_TEMP_DE_TIME_REMAINING_TEXT", "Verbleibende Zeit: ");
###################################
#       LANGUAGE AT               #
###################################
define("PB_TEMP_AT_BID_NOW_LINK", "Jetzt bieten");
define("PB_TEMP_AT_BIN_LINK", "Sofort-Kaufen");
define("PB_TEMP_AT_ADD_LINK", "Zur Liste der beobachteten Artikel hinzufügen");
define("PB_TEMP_AT_BIDS_TEXT", " (%%NumBids%% Gebote)");
define("PB_TEMP_AT_BIN_TEXT", "Sofort-Kaufen für nur: ");
define("PB_TEMP_AT_END_DATE_TEXT", "Angebotsende: ");
define("PB_TEMP_AT_TIME_REMAINING_TEXT", "Verbleibende Zeit: ");
###################################
#       LANGUAGE BE               #
###################################
define("PB_TEMP_BE_BID_NOW_LINK", "Enchérir");
define("PB_TEMP_BE_BIN_LINK", "Enchérir");
define("PB_TEMP_BE_ADD_LINK", "Ajouter à vos Affaires à suivre");
define("PB_TEMP_BE_BIDS_TEXT", " (%%NumBids%% Enchère)");
define("PB_TEMP_BE_BIN_TEXT", "Achat immédiat pour seulement: ");
define("PB_TEMP_BE_END_DATE_TEXT", "Date de fin: ");
define("PB_TEMP_BE_TIME_REMAINING_TEXT", "Temps restant: ");
###################################
#       LANGUAGE CH               #
###################################
define("PB_TEMP_CH_BID_NOW_LINK", "Jetzt bieten");
define("PB_TEMP_CH_BIN_LINK", "Sofort-Kaufen");
define("PB_TEMP_CH_ADD_LINK", "Zur Liste der beobachteten Artikel hinzufügen");
define("PB_TEMP_CH_BIDS_TEXT", " (%%NumBids%% Gebote)");
define("PB_TEMP_CH_BIN_TEXT", "Sofort-Kaufen für nur: ");
define("PB_TEMP_CH_END_DATE_TEXT", "Angebotsende: ");
define("PB_TEMP_CH_TIME_REMAINING_TEXT", "Verbleibende Zeit: ");
###################################
#       LANGUAGE ES               #
###################################
define("PB_TEMP_ES_BID_NOW_LINK", "Pujar ahora");
define("PB_TEMP_ES_BIN_LINK", "¡Cómpralo ya!");
define("PB_TEMP_ES_ADD_LINK", "Añadir a lista de seguimiento");
define("PB_TEMP_ES_BIDS_TEXT", " (%%NumBids%% Pujas)");
define("PB_TEMP_ES_BIN_TEXT", "Cómpralo ya por sólo: ");
define("PB_TEMP_ES_END_DATE_TEXT", "Fecha de finalización: ");
define("PB_TEMP_ES_TIME_REMAINING_TEXT", "Tiempo Restante: ");
###################################
#       LANGUAGE FR               #
###################################
define("PB_TEMP_FR_BID_NOW_LINK", "Enchérir");
define("PB_TEMP_FR_BIN_LINK", "Achat immédiat");
define("PB_TEMP_FR_ADD_LINK", "Ajouter à vos Affaires à suivre");
define("PB_TEMP_FR_BIDS_TEXT", " (%%NumBids%% Enchères)");
define("PB_TEMP_FR_BIN_TEXT", "Achat immédiat pour seulement: ");
define("PB_TEMP_FR_END_DATE_TEXT", "Date de fin: ");
define("PB_TEMP_FR_TIME_REMAINING_TEXT", "Temps restant: ");
###################################
#       LANGUAGE IT               #
###################################
define("PB_TEMP_IT_BID_NOW_LINK", "Fai un'offerta");
define("PB_TEMP_IT_BIN_LINK", "Compralo Subito");
define("PB_TEMP_IT_ADD_LINK", "Aggiungi all'elenco degli oggetti che osservi");
define("PB_TEMP_IT_BIDS_TEXT", " (%%NumBids%% Offerte)");
define("PB_TEMP_IT_BIN_TEXT", "Compralo Subito per soli: ");
define("PB_TEMP_IT_END_DATE_TEXT", "Scadenza: ");
define("PB_TEMP_IT_TIME_REMAINING_TEXT", "Tempo rimanente: ");
###################################
#       LANGUAGE NL               #
###################################
define("PB_TEMP_NL_BID_NOW_LINK", "Nu bieden");
define("PB_TEMP_NL_BIN_LINK", "Nu kopen");
define("PB_TEMP_NL_ADD_LINK", "Toevoegen aan volglijst");
define("PB_TEMP_NL_BIDS_TEXT", " (%%NumBids%% Biedingen)");
define("PB_TEMP_NL_BIN_TEXT", "Nu kopen voor slechts: ");
define("PB_TEMP_NL_END_DATE_TEXT", "Einddatum: ");
define("PB_TEMP_NL_TIME_REMAINING_TEXT", "Resterende tijd: ");
###################################
#              MISC               #
###################################
define("PB_MAXRESULTS", "");
define("PB_META_KEYWORD_VALUE", "keywords");
define("PB_MAXMIND", false);
define("PB_MAXMINDLICENSE", "");
define("PB_CACHE_CLEARED", "phpBay Pro cache files were cleared.");
###################################
#          JQUERY URLS            #
###################################
# jquery note.  If conflicts, set PB_JQUERY_URL to ""
# jquery must be enabled to use the asin tabs template or other jquery based
# if not using asin tabs template or custom jquery based template in phpBay Pro
# you can set PB_JQUERY_URL, PB_JQUERY_UI_URL and PB_JQUERY_UI_CSS_URL = "" below.
# when jquery version changes, update both PB_JQUERY_URL and the PB_JQUERY_VER values.
# Place holder for future upgrade
define("PB_JQUERY_URL", "http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js");
define("PB_JQUERY_VER", "1.8.2");
define("PB_JQUERY_FORCE_REGISTER", false);
# if PB_JQUERY_FORCE_OFF it will force it to not load jquery.  If you have the stealth mode
# extension, this means it will not work if set to true.
define("PB_JQUERY_FORCE_OFF", false);
# define("PB_JQUERY_UI_URL", "http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.js");
# define("PB_JQUERY_UI_VER", "1.7.2");
# you can use any of the themes from jquery UI.  URLs to individual themes can be found here:
# http://blog.jqueryui.com/2009/06/jquery-ui-172/
# this url is for version 1.7.2 themes.  You may need to check the blog above when version goes higher.
# be sure to copy the theme url and paste below to change use the desired theme.
# define("PB_JQUERY_UI_CSS_URL", "http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/themes/start/jquery-ui.css");
##############################################
# DO NOT MODIFY THESE - FOR USE IN DASHBOARD
##############################################
define("PB_ADMIN_JQUERY_URL", "http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js");
define("PB_ADMIN_JQUERY_VER", "1.8.2");
define("PB_ADMIN_JQUERY_UI_URL", "http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.0/jquery-ui.js");
define("PB_ADMIN_JQUERY_UI_VER", "1.9.0");
define("PB_ADMIN_JQUERY_UI_CSS_URL", "http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.0/themes/start/jquery-ui.css");
define("PB_ADMIN_JQUERY_FORCE_REGISTER", false);
define("PB_ADMIN_JQUERY_TOOLS_URL", "http://cdn.jquerytools.org/1.2.7/full/jquery.tools.min.js");
define("PB_ADMIN_JQUERY_TABS_CODE_NAME", "jquery.tabs.code.js");
##############################################
# only set this if your host locks down your server and needs an outbound port
# to open, in order to use phpBay Pro.  Uncomment the next line and enter the port
# number as the second parameter (replace 80 with your port number)
#define("PB_CURL_PORT", 80);
# next line is for use if server is Godaddy, but can be changed
# to another proxy url.  Corresponds to the Godaddy setting in
# settings.
# define("PB_CURL_PROXY", "http://proxy.shr.secureserver.net:3128");
###################################
#          CURL SETTINGS          #
###################################
# PB_CURL_TIMEOUT - The number of seconds to wait while trying to connect to ebay's rss server.
# If ebay's rss server goes offline, you can set the value below from 8 to 2 or 3 so it will not hang up your server.
define("PB_CURL_TIMEOUT", 20);
# PB_CURL_CONNECTTIMEOUT - The maximum number of seconds to allow cURL functions to execute.
define("PB_CURL_CONNECTTIMEOUT", 20);
###################################
#       EPN SETTINGS       #
###################################
define("PB_EPN_RSS_URL", "http://rest.ebay.com/epn/v1/find/item.rss?");
define("PB_EPN_DEFAULT_SORT_ORDER", "EndTimeSoonest");
define("PB_EPN_DEFAULT_SITE_ID", "1");
define("PB_EPN_DEFAULT_LISTING_TYPE", "All");
define("PB_EPN_DEFAULT_MAX_DISTANCE", "100");
define("PB_EPN_DEFAULT_NUM_LISTINGS", 100);
define("PB_EPN_WATCH_URL_PREFIX", "watch-list-");
define("PB_EPN_BID_URL_PREFIX", "bid-");
define("PB_EPN_BIN_URL_PREFIX", "bin-");
define("PB_EPN_SMALL_IMAGES_URL", "http://thumbs.ebaystatic.com/pict/");
define("PB_EPN_IMAGES_FOLDER", "media/1/images/e/");
# This value should be blank "", or "4040"  If you change it, your images may not work.
define("PB_EPN_IMAGES_ID", "4040");
###################################
define("PB_TIME_REMAINING_FORMAT", "%%days%% %%hours%% %%minutes%%");
define("PB_TIME_REMAINING_DAY", "d");
define("PB_TIME_REMAINING_HOUR", "h");
define("PB_TIME_REMAINING_MINUTE", "m");
###################################
if (!defined("PBZ_UNIQUE_ID")) {
	define("PBZ_UNIQUE_ID", "wp-jquery-src");
}
define("PB_EBAY_LOGO", "logo.png");
define("PB_AUCTION_FILE_NAME", "auction.php");
define("PB_IMAGES_FOLDER", "media/1/images/f/");
define("PB_MEDIA_FOLDER", "media/1/");
define("PB_JS_FOLDER", "media/1/js/");
define("PB_JS_FILE_NAME", "jquery.code.js");
define("PB_PREG_MATCH_IMAGE", "/(?<=src=\')(.*?)(?=jpg)/");
define("PB_EVAL_RESULTS", true);
define("PB_COUNTRY_CODE", "");
define("PB_DISABLE_FILE_GET_CONTENTS", false);
define("PB_USE_URL_WITH_FILE_GET_CONTENTS", false);
# set the following constant to true, if extra <p> tags/spaces are in output
define("PB_ENABLE_WPAUTOP", false);
# example for PB_GEO_IP_PATH - /home/user/public_html/geo/
# for linux based servers, path must start with / and end with /
# leave blank to use default path in phpBay Pro
define("PB_GEO_IP_PATH", "");
define("PB_GEO_IP_DEFAULT_COUNTRY", "");
?>