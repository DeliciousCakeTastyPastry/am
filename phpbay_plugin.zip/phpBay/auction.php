<?php
ob_start();
error_reporting(0);
##############################################################
#    SETTINGS                                                #
##############################################################
# VALID USER AGENT LIST
# Determine if valid user agent
$valid_user_agents = array();
$valid_user_agents[] = "firefox";
$valid_user_agents[] = "chrome";
$valid_user_agents[] = "galeon";
$valid_user_agents[] = "msie";
$valid_user_agents[] = "safari";
$valid_user_agents[] = "opera";
$valid_user_agents[] = "navigator";
$valid_user_agents[] = "epiphany";
$valid_user_agents[] = "konqueror";
$valid_user_agents[] = "k-meleon";
$valid_user_agents[] = "blackberry";
$valid_user_agents[] = "AvantGo";
$valid_user_agents[] = "Bolt";
$valid_user_agents[] = "DoCoMo";
$valid_user_agents[] = "P502i";
$valid_user_agents[] = "Vodafone";
$valid_user_agents[] = "AIR-EDGE";
$valid_user_agents[] = "Dolphin";
$valid_user_agents[] = "EudoraWeb";
$valid_user_agents[] = "ftxBrowser";
$valid_user_agents[] = "Minimo";
$valid_user_agents[] = "OpenWave";
$valid_user_agents[] = "PocketLink";
$valid_user_agents[] = "Plucker";
$valid_user_agents[] = "NetFront";
$valid_user_agents[] = "PIE";
$valid_user_agents[] = "Xiino";
$valid_user_agents[] = "BenQ";
$valid_user_agents[] = "BB10";
$valid_user_agents[] = "layBook";
$valid_user_agents[] = "Cricket";
$valid_user_agents[] = "MOT";
$valid_user_agents[] = "Nintendo";
$valid_user_agents[] = "Nokia";
$valid_user_agents[] = "Nook";
$valid_user_agents[] = "HTC";
$valid_user_agents[] = "O2";
$valid_user_agents[] = "Palm";
$valid_user_agents[] = "Pantech";
$valid_user_agents[] = "Pocket PC";
$valid_user_agents[] = "PPC";
$valid_user_agents[] = "SAGEM";
$valid_user_agents[] = "SAMSUNG";
$valid_user_agents[] = "Sanyo";
$valid_user_agents[] = "Sharp";
$valid_user_agents[] = "SIE";
$valid_user_agents[] = "Sony";
$valid_user_agents[] = "Sprint";
$valid_user_agents[] = "UCWEB";
$valid_user_agents[] = "iphone";
$valid_user_agents[] = "ipad";
$valid_user_agents[] = "rv";
##############################################################
# IP BAN LIST
##############################################################
# if you want to ban certain country ip ranges, enter them
# in an array list below.
$ban_ip_range = array();
# Below, you can add in your own IP address blocks
# You will need to uncomment (remove the // )
# from $ban_ip_range[] = "xx.";
# lines below and add in your own ip address blocks
# These can be specified as:
# $ban_ip_range[] = "58.";
# $ban_ip_range[] = "58.111.";
# $ban_ip_range[] = "58.111.222.";
##############################################################
# COUNTRY BAN LIST
##############################################################
# Add a line for each country along with the two letter country
# code, for each country to ban.
$ban_country = array();
$ban_country[] = "CN";
$ban_country[] = "RU";
# $ban_country[] = "";
##############################################################
# END SETTINGS
##############################################################
#    IS BOT?                                                 #
##############################################################
$filename = dirname(__FILE__) . "/phpbay/config.php";
if (file_exists($filename)) {
		# API
} else {
	# WP
	# where are we?  get the path of this file and break each segment into array
	$temp = explode("/", $_SERVER["SCRIPT_FILENAME"]);
	# pop off /auction.php
	array_pop($temp);
	# pop off /phpBay
	array_pop($temp);
	# pop off /plugins
	array_pop($temp);
	# pop off /wp-content
	array_pop($temp);
	# what's left is the root folder of the blog (not necessarily the site)
	$temp = implode("/", $temp) . "/wp-blog-header.php";
	require($temp);
	$pb_options = array();
	$pb_temp = get_option("pb_options");
	if (!empty($pb_temp)) {
		foreach ($pb_temp as $key => $option)
			$pb_options[$key] = $option;
	}
	unset($pb_temp);
}
$filename = dirname(__FILE__) . "/includes/isbot.php";
if (file_exists($filename)) {
	if (!defined("PBZX_SAFE")) {
		require_once($filename);
	}
}
##############################################################
# CHECK VALID REFERER
##############################################################
$ua_approved = false;
# Get the user agent of the current agent browsing this page
$current_user_agent = strtolower($_SERVER['HTTP_USER_AGENT']);
# Is current user agent in the approvided list?
foreach ($valid_user_agents as $key => $value) {
	if(strstr($current_user_agent, strtolower($value))) {
		$ua_approved = true;
	}
}
# Determine if referer is correct.  We compare our domain name
# to the outgoing referer to make sure the referer is correct
# before going to Ebay.  Strip out the "www." of both the host
# and referrer so we have an accurate match.
$referer_approved = false;
$host = strtolower("http://" . str_replace("www.", "",$_SERVER["HTTP_HOST"])) . "/";
$referer = substr(strtolower($_SERVER['HTTP_REFERER']),0);
$referer = str_replace("www.", "",$referer);
$temp = explode("/", $referer);
$referer = "http://" . $temp[2] . "/";
if ($host == $referer){$referer_approved = true;}
##############################################################
#    CHECK IP BAN LIST                                       #
##############################################################
function check_ban_ips($ip_range) {
	$ip = $_SERVER['REMOTE_ADDR'];
	$approved = true;
	if(is_array($ip_range)) {
		foreach ($ip_range as $ip_check) {
			if (strpos($ip, $ip_check) === 0) {
				$approved = false;
			}
		}
	}
	return $approved;
}
$ip_approved = check_ban_ips($ban_ip_range);
##############################################################
# CHECK FOR VALID IP ADDRESS
##############################################################
function ValidIP($ip) {
	if ((!empty($ip)) && (ip2long($ip) != -1)) {
		$reserved_ips = array (
			array('0.0.0.0','2.255.255.255'),
			array('10.0.0.0','10.255.255.255'),
			array('127.0.0.0','127.255.255.255'),
			array('169.254.0.0','169.254.255.255'),
			array('172.16.0.0','172.31.255.255'),
			array('192.0.2.0','192.0.2.255'),
			array('192.168.0.0','192.168.255.255'),
			array('255.255.255.0','255.255.255.255')
			);
			foreach ($reserved_ips as $invalid) {
				$min = ip2long($invalid[0]);
				$max = ip2long($invalid[1]);
				if ((ip2long($ip) >= $min) && (ip2long($ip) <= $max)) return false;
			}
			return true;
	} else {
		return false;
	}
}
function pb_GetIP() {
	if (ValidIP($_SERVER["HTTP_CLIENT_IP"])) {return $_SERVER["HTTP_CLIENT_IP"];}
	foreach (explode(",",$_SERVER["HTTP_X_FORWARDED_FOR"]) as $ip) {if (ValidIP(trim($ip))) {return $ip;}}
	if (ValidIP($_SERVER["HTTP_X_FORWARDED"])) {
		return $_SERVER["HTTP_X_FORWARDED"];
	} elseif (ValidIP($_SERVER["HTTP_FORWARDED_FOR"])) {
		return $_SERVER["HTTP_FORWARDED_FOR"];
	} elseif (ValidIP($_SERVER["HTTP_FORWARDED"])) {
		return $_SERVER["HTTP_FORWARDED"];
	} elseif (ValidIP($_SERVER["HTTP_X_FORWARDED"])) {
		return $_SERVER["HTTP_X_FORWARDED"];
	} else {
		return $_SERVER["REMOTE_ADDR"];
	}
}
##############################################################
# LOAD MAXMIND API AND CHECK COUNTRY CODE OF IP
##############################################################
# Load the Maxmind API
require_once(dirname(__FILE__) . "/lang/english.php");
if (PB_GEO_IP_PATH > "") {
	if (!class_exists("GeoIP")) {
		require_once(PB_GEO_IP_PATH . "geoip.inc");
	}
# Open the Maxmind database
	$gi = geoip_open(PB_GEO_IP_PATH . "GeoIP.dat", GEOIP_STANDARD);
} else {
	if (!class_exists("GeoIP")) {
		require_once(dirname(__FILE__) . "/includes/geoip.inc");
	}
# Open the Maxmind database
	$gi = geoip_open(dirname(__FILE__) . "/includes/GeoIP.dat", GEOIP_STANDARD);
}
# Get the Country Code for the IP address
$country = strtoupper(geoip_country_code_by_addr($gi, pb_GetIP()));
# Close the database connection
geoip_close($gi);
# Is country in banned list?
$approved = true;
if(is_array($ban_country)) {
	foreach ($ban_country as $country_check) {
		if (strpos($country, $country_check)===0) {
			$approved = false;
		}
	}
}
$country_approved = $approved;
##############################################################
#  CAN WE PROCEED TO EBAY?
##############################################################
# if stealth extension is installed and returns "safe"
if (defined("PBZX_SAFE")) {
	if (PBZX_SAFE) {
		$is_safe = true;
	} else {
		$is_safe = false;
	}
} else {
# if the stealth extension is not installed, then assume safe
# you really should consider adding this extension as it
# performs a number of advanced safeguards to prevent
# search engine bots from getting through
	$is_safe = true;
}
# if any of the following conditions are not true, then ip address should not proceed
if ((!$ua_approved) || (!$referer_approved) || (!$ip_approved) || (!$country_approved) || (!$is_safe)) {
# additional safeguard headers are sent if the stealth extension
# is installed and returns not "safe"
	header("HTTP/1.1 410 Gone");
	exit;
} else {
##############################################################
#  MAKE IT SO, NUMBER ONE
##############################################################
	$pb_request["customid"] = $_REQUEST["ccid"];
	# if custom id = 0 then we unset it
	if ($pb_request["customid"] == "0") {unset($pb_request["customid"]);}
	$pb_request["campaignid"] = $_REQUEST["campaignid"];
	$pb_request["country"] = $_REQUEST["country"];
	$pb_request["item"] = $_REQUEST["item"];
	$pb_request["title"] = $_REQUEST["title"];
	if (isset($_REQUEST["linktype"])) {
		if ($_REQUEST["linktype"] == "watch") {
			$pb_request["linktype"] = "watch";
		} else if ($_REQUEST["linktype"] == "more") {
			$pb_request["linktype"] = "more";
		} else {
			$pb_request["linktype"] = "normal";
		}
	} else {
			$pb_request["linktype"] = "normal";
	}
	if (isset($_REQUEST["mode"])) {
		if ($_REQUEST["mode"] == "debug") {
			$pb_request["mode"] = "debug";
		} else {
			$pb_request["mode"] = "normal";
		}
	} else {
			$pb_request["mode"] = "normal";
	}
	if (!isset($pb_request["campaignid"])) {
		$pb_request["campaignid"] = $pb_options["campaignid"];
	}
	if (!isset($pb_request["customid"])) {
		$pb_request["customid"] = $pb_options["customid"];
	}
		$pb_request["siteId"] = $pb_options["siteId"];
		if (($pb_options["SkimLinks"]) && ($pb_options["VigLinks"])) {
			# meaning both are setup and we randomly send links to skimlinks and viglinks
			$x = rand(1,2);
			# if $x == 1 then skimlinks is selected
			# if $x == 2 then viglinks is selected
			if ($x == 1) {$pb_options["SkimLinks"] = "1";$pb_options["VigLinks"]="0";}
			if ($x == 2) {$pb_options["SkimLinks"] = "0";$pb_options["VigLinks"]="1";}
		}

		# Determine Custom ID
		if ($pb_request["customid"] > "") {
			$pb_request["customid"] = urlencode(trim($pb_request["customid"]));
		} else {
			$pb_request["customid"] = urlencode(trim($pb_options["customid"]));
		}

		# Determine Country
		$pb_CountryCodes = array("1" => "US", "2" => "IE", "3" => "AT", "4" => "AU", "5" => "BE", "7" => "CA", "10" => "FR", "11" => "DE", "12" => "IT", "13" => "ES", "14" => "CH", "15" => "GB", "16" => "NL");
		if ($pb_request["country"] > "") {
			$pb_request["country"] = urlencode(trim($pb_request["country"]));
		} else {
			$pb_request["country"] = $pb_CountryCodes[$pb_request["siteId"]];
		}

	switch($pb_request["country"]) {
		case "US":
			$pb_request["roverid"] = "711-53200-19255-0";
			$pb_request["vectorid"] = "229466";
			$pb_request["domain"] = "ebay.com";
			break;
		case "IE":
			$pb_request["roverid"] = "5282-53468-19255-0";
			$pb_request["vectorid"] = "229543";
			$pb_request["domain"] = "ebay.ie";
			break;
		case "AT":
			$pb_request["roverid"] = "5221-53469-19255-0";
			$pb_request["vectorid"] = "229473";
			$pb_request["domain"] = "ebay.at";
			break;
		case "AU":
			$pb_request["roverid"] = "705-53470-19255-0";
			$pb_request["vectorid"] = "229515";
			$pb_request["domain"] = "ebay.com.au";
			break;
		case "BE":
			$pb_request["roverid"] = "1553-53471-19255-0";
			$pb_request["vectorid"] = "229522";
			$pb_request["domain"] = "benl.ebay.be";
			#if you would prefer to use Belgium France, comment the line directly above
			# and uncomment the line directly below
			# $pb_request["domain"] = "befr.ebay.be";
			break;
		case "CA":
			$pb_request["roverid"] = "706-53473-19255-0";
			$pb_request["vectorid"] = "229529";
			$pb_request["domain"] = "ebay.ca";
			break;
		case "FR":
			$pb_request["roverid"] = "709-53476-19255-0";
			$pb_request["vectorid"] = "229480";
			$pb_request["domain"] = "ebay.fr";
			break;
		case "DE":
			$pb_request["roverid"] = "707-53477-19255-0";
			$pb_request["vectorid"] = "229487";
			$pb_request["domain"] = "ebay.de";
			break;
		case "IT":
			$pb_request["roverid"] = "724-53478-19255-0";
			$pb_request["vectorid"] = "229494";
			$pb_request["domain"] = "ebay.it";
			break;
		case "ES":
			$pb_request["roverid"] = "1185-53479-19255-0";
			$pb_request["vectorid"] = "229501";
			$pb_request["domain"] = "ebay.es";
			break;
		case "CH":
			$pb_request["roverid"] = "5222-53480-19255-0";
			$pb_request["vectorid"] = "229536";
			$pb_request["domain"] = "ebay.ch";
			break;
		case "GB":
			$pb_request["roverid"] = "710-53481-19255-0";
			$pb_request["vectorid"] = "229508";
			$pb_request["domain"] = "ebay.co.uk";
			break;
		case "NL":
			$pb_request["roverid"] = "1346-53482-19255-0";
			$pb_request["vectorid"] = "229557";
			$pb_request["domain"] = "ebay.nl";
			break;
    	default:
			$pb_request["roverid"] = "711-53200-19255-0";
			$pb_request["vectorid"] = "229466";
			$pb_request["domain"] = "ebay.com";
			break;
	}
	if (($pb_options["SkimLinks"] == "1") && ($pb_options["SkimLinksID"] > "")) {
		if ($pb_request["linktype"] == "normal") {
			# if link is to a normal ebay item via skimlinks
			$url = "http://go.redirectingat.com?id=" . $pb_options["SkimLinksID"] . "&xs=1&url=" . urlencode("http://www." . $pb_request["domain"] . "/itm/" . $pb_request["title"] . "/" . $pb_request["item"]);
		} else {
			# else the link is a watch list link via skimlinks
			$url = "http://go.redirectingat.com?id=" . $pb_options["SkimLinksID"] . "&xs=1&url=" . urlencode("http://cgi1." . $pb_request["domain"] . "/ws/eBayISAPI.dll?MfcISAPICommand=MakeTrack&item=" . $pb_request["item"]);
		}
	} elseif (($pb_options["VigLinks"] == "1") && ($pb_options["VigLinksID"] > "")) {
		$pb_request["referer"] = $_SERVER["HTTP_REFERER"];
		if ($pb_request["linktype"] == "normal") {
			# if link is to a normal ebay item via viglink
			$url = "http://cdn.viglink.com/api/click?format=text" .
					"&key=" . urlencode($pb_options["VigLinksID"]) .
					"&loc=" . urlencode($pb_request["referer"]) .
					//"&out=" . urlencode("http://www." . $pb_request["domain"] . "/itm/ws/eBayISAPI.dll?ViewItem&Item=" . $pb_request["item"]);
					"&out=" . urlencode("http://www." . $pb_request["domain"] . "/itm/" . $pb_request["title"] . "/" . $pb_request["item"]);
		} else {
			# else the link is a watch list link via viglink
			$url = "http://api.viglink.com/api/click?key=" . urlencode($pb_options["VigLinksID"] . "&format=txt" . "&ref=" . $referer . "&cuid=" . $pb_request["customid"] . "&out=http://cgi1." . $pb_request["domain"] . "/ws/eBayISAPI.dll?MfcISAPICommand=MakeTrack&item=" . $pb_request["item"]);
		}
	} else {
		if ($pb_request["linktype"] == "normal") {
			$url = "http://rover.ebay.com/rover/1/" . $pb_request["roverid"] . "/1?ff3=2&toolid=10039&campid=" . $pb_request["campaignid"] . "&customid=" . $pb_request["customid"] . "&item=" . $pb_request["item"] . "&vectorid=" . $pb_request["vectorid"] . "&lgeo=1";
		} else {
			$url = "http://rover.ebay.com/rover/1/" . $pb_request["roverid"] . "/1?ff3=4&toolid=10039&campid=" . $pb_request["campaignid"] . "&customid=" . $pb_request["customid"] . "&vectorid=" . $pb_request["vectorid"] . "&lgeo=1&mpre=" . urlencode("http://cgi1." . $pb_request["domain"] . "/ws/eBayISAPI.dll?MfcISAPICommand=MakeTrack&item=" . $pb_request["item"]);
		}
	}
	# if more link
	if ($pb_request["linktype"] == "more") {
		$url = "http://rover.ebay.com/rover/1/" . $pb_request["roverid"] . "/1?icep_ff3=9&toolid=10001&campid=" . $pb_request["campaignid"] . "&customid=" . $pb_request["customid"] . "&icep_uq=" . str_replace('-', '+', $pb_request["title"]) . "&icep_sellerId=&icep_ex_kw=&icep_sortBy=12&icep_catId=&icep_minPrice=&icep_maxPrice=&ipn=psmain&icep_vectorid=" . $pb_request["vectorid"] . "&kwid=902099&mtid=824&kw=lg";
	}
	# if debug mode
	if ($pb_request["mode"] == "debug") {
		echo "Debug output...<br />\r\n";
		echo "Raw Ebay url = " . "http://www." . $pb_request["domain"] . "/itm/" . $pb_request["title"] . "/" . $pb_request["item"] . "<br />\r\n";
		echo "campaignid = " . $pb_request["campaignid"] . "<br />\r\n";
		echo "customid = " . $pb_request["customid"] . "<br />\r\n";
		echo "country = " . $pb_request["country"] . "<br />\r\n";
		echo "item = " . $pb_request["item"] . "<br />\r\n";
		echo "linktype = " . $pb_request["linktype"] . "<br />\r\n";
		if (defined("PBZX_SAFE")) {
			echo "stealth isbot.php path = " . $filename . "<br />\r\n";
		}
		if ($pb_options["SkimLinks"] == "1") {
			echo "Skimlinks is active<br />\r\n";
		}
		if ($pb_options["VigLinks"] == "1") {
			echo "Viglinks is active<br />\r\n";
		}
		echo "url = " . $url . "<br />\r\n";
		echo "End Debug output...<br />\r\n";
		exit;
	}
	if ($url > "") {
		header("Location: " . $url, true, 301);
		exit;
	}
}
?>