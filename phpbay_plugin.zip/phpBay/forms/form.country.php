<form method="post" action="" style="margin:0;padding:0;height:26px;">
	<select onchange="javascript:submit();" id="country" name="country">
		<option value="US">United States</option>
		<option value="AU">Australia</option>
		<option value="AT">Austria</option>
		<option value="BE">Belgium</option>
		<option value="CA">Canada</option>
		<option value="FR">France</option>
		<option value="DE">Germany</option>
		<option value="IE">Ireland</option>
		<option value="IT">Italy</option>
		<option value="NL">Netherlands</option>
		<option value="ES">Spain</option>
		<option value="CH">Switzerland</option>
		<option value="GB">Great Britain</option>
	</select>
</form>

