<script type="text/javascript">
<!-- Begin
function Sort_%%ID%%(){
  document.forms['sort_%%ID%%'].submit();
}
// End -->
</script>
<form name="sort_%%ID%%" id="sort_%%ID%%" method="post" action="" style="width:100%;margin:0px;padding:0px;text-align:right;height:26px;">
  <select name="sortnum_%%ID%%" onchange="Sort_%%ID%%();" style="width: 170px;margin:0;padding:0;">
    <option value="BestMatch">Best Match</option>
    <option value="EndTimeSoonest">Items Ending First</option>
    <option value="StartTimeNewest">Newly-Listed Items First</option>
    <option value="PricePlusShippingLowest">Price + Shipping: Lowest First</option>
    <option value="PricePlusShippingHighest">Price + Shipping: Highest First</option>
  </select>
<input name="country" type="hidden" value="%%country%%" />
</form>
