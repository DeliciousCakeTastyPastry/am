<table width="100%" border="0" cellspacing="2" cellpadding="2" style="background-color:#eaeaea">
  <tr>
    <td style="vertical-align:middle;">%%logo%%</td>
    <td style="vertical-align:middle;">%%geo%%</td>
    <td style="vertical-align:middle;">%%sort%%</td>
  </tr>
</table>
