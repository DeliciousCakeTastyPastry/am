jQuery(document).ready(function($){
	$('#tabs').tabs();
});
function stealth() {
	if (document.getElementById('pbp474da23b7cc01e1f4e67cd5b6220b647_1').checked == false) {
		if (document.getElementById('PB_Stealth').checked == true) {
			document.getElementById('pbp474da23b7cc01e1f4e67cd5b6220b647_1').checked = true;
		}
	}
}
function recommended1() {
	document.phpbay.pbp42391a12afe8c595d7bd09ec72d0283d.checked = true;
	document.phpbay.pbp90122b3165d933ab715387d7029eb56a.checked = true;
	document.phpbay.pbp88191be4d24cd1abc15d320a6945ee4c.checked = true;
	document.phpbay.pbp309007426b329b04825e7bf3529dd1a9.pbp309007426b329b04825e7bf3529dd1a9_1.checked = true;
	document.phpbay.pbp95703edab62accdd79c8c812b893a99c.checked = true;
	document.phpbay.pbp83712f536a59e70ecb8fe5da05875d42.checked = true;
	document.phpbay.pbpc897f65d52c3bac7b1b9c322c4b2227b.checked = true;
}
