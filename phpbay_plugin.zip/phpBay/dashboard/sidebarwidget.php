<?php
class phpBay_Widget extends WP_Widget {
    function phpBay_Widget() {
        parent::WP_Widget(false, $name = 'phpBay Pro Sidebar Widget', array('description' => 'Add Ebay products to your sidebar with phpBay Pro Widget.'));
    }

    function widget($args, $instance) {
		global $pb_sidebar;
		$pb_temp = get_option("widget_phpbay_widget");
		if (!empty($pb_temp)) {
			foreach ($pb_temp as $key)
				if (count($key) > 9) {
					$first_ID = intval($key['id']);
					if ($first_ID > 0) {break;}
				}
		}
		$pb_temp = get_option("pb_options");
		if (!empty($pb_temp)) {
			foreach ($pb_temp as $key => $option)
				$pb_options[$key] = $option;
		}
		if ((!function_exists('register_sidebar_widget')) || (!function_exists('register_widget_control'))) {return;}
		if (!is_numeric($pb_sidebar["id"])) {$pb_sidebar["id"] = $first_ID;}
        if ((isset($pb_sidebar["results"])) && ($this->number == $pb_sidebar["id"])) {
			if ($this->number == intval($pb_sidebar["id"])) {
				extract($args);
				$title = apply_filters("widget_title", $pb_sidebar["title"]);
				echo $before_widget;
				if ($title > "") {echo $before_title . $title . $after_title;}
				echo $pb_sidebar["results"];
				echo $after_widget;
				$pb_sidebar = array();
			}
		} else {
			if ((is_home() || is_front_page()) && ($instance["homepage"] == "1")) {return;}
			extract($args);
			$title = apply_filters("widget_title", $instance["title"]);
			echo $before_widget;
###########################
	if ($pb_options["DisplayLogoSidebar"]) {
		$this->path["blog_url"] = get_bloginfo("wpurl") . "/";
		if ($pb_options["Rewrite"] == "1") {
			$this->path["images_url"] = $this->path["blog_url"] . PB_IMAGES_FOLDER;
		} else {
			$this->path["images_url"] = WP_PLUGIN_URL . "/phpBay/media/images/";
		}
		$logo = PB_TEMP_SIDEBAR_EBAY_LOGO;
		$logo = str_replace("%%logo%%", $this->path["images_url"] . PB_EBAY_LOGO, $logo) . "<br />\r\n";
	} else {
		$logo = "";
	}

###########################

			if ($title > "") {echo $before_title . $logo . $title . $after_title;}
			echo phpbay_sidebar_widget($instance);
			echo $after_widget;
		}
    }

    function update($new_instance, $old_instance) {
        return $new_instance;
    }

    function form($instance) {
		$pb_temp = get_option("pb_options");
		if (!empty($pb_temp)) {
			foreach ($pb_temp as $key => $option)
				$pb_options[$key] = $option;
		}
        $title = esc_attr($instance['title']);
        $keywords = esc_attr($instance['keywords']);
        $num = esc_attr($instance['num']);
        $customid = esc_attr($instance['customid']);
        $siteid = esc_attr($instance['siteid']);
		if ($siteid == "") {$siteid = $pb_options["siteId"];}
        $category = esc_attr($instance['category']);
        $sort = esc_attr($instance['sort']);
        $minprice = esc_attr($instance['minprice']);
        $maxprice = esc_attr($instance['maxprice']);
        $sellerid = esc_attr($instance['sellerid']);
        $freeshipping = esc_attr($instance['freeshipping']);
        $homepage = esc_attr($instance['homepage']);
        $listingtype = esc_attr($instance['listingtype']);
        $minbid = esc_attr($instance['minbid']);
        $maxbid = esc_attr($instance['maxbid']);
        ?>
           <p><?php echo PB_WIDGET_INSTRUCTIONS; ?></p>
            <p><label for="<?php echo $this->get_field_id("title"); ?>"><?php _e(PB_WIDGET_TITLE . ":"); ?> <input class="widefat" id="<?php echo $this->get_field_id("title"); ?>" name="<?php echo $this->get_field_name("title"); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
            <p><label for="<?php echo $this->get_field_id("keywords"); ?>"><?php _e(PB_WIDGET_KEYWORDS . ":"); ?> <input class="widefat" id="<?php echo $this->get_field_id("keywords"); ?>" name="<?php echo $this->get_field_name("keywords"); ?>" type="text" value="<?php echo $keywords; ?>" /></label></p>
            <p><label for="<?php echo $this->get_field_id("category"); ?>"><?php _e(PB_WIDGET_CATEGORY . ":"); ?> <input class="widefat" id="<?php echo $this->get_field_id("category"); ?>" name="<?php echo $this->get_field_name("category"); ?>" type="text" value="<?php echo $category; ?>" /></label></p>
            <p><label for="<?php echo $this->get_field_id("customid"); ?>"><?php _e(PB_WIDGET_CUSTOM_ID . ":"); ?> <input class="widefat" id="<?php echo $this->get_field_id("customid"); ?>" name="<?php echo $this->get_field_name("customid"); ?>" type="text" value="<?php echo $customid; ?>" /></label></p>
            <p><label for="<?php echo $this->get_field_id("num"); ?>"><?php _e(PB_WIDGET_NUMBER . ":"); ?>
				<select name="<?php echo $this->get_field_name("num"); ?>" id="<?php echo $this->get_field_id("num"); ?>" class="widefat">
					<option value="1"<?php if ($num == "1") {echo " selected";}?>>1</option>
					<option value="2"<?php if ($num == "2") {echo " selected";}?>>2</option>
					<option value="3"<?php if ($num == "3") {echo " selected";}?>>3</option>
					<option value="4"<?php if ($num == "4") {echo " selected";}?>>4</option>
					<option value="5"<?php if ($num == "5") {echo " selected";}?>>5</option>
					<option value="6"<?php if ($num == "6") {echo " selected";}?>>6</option>
					<option value="7"<?php if ($num == "7") {echo " selected";}?>>7</option>
					<option value="8"<?php if ($num == "8") {echo " selected";}?>>8</option>
					<option value="9"<?php if ($num == "9") {echo " selected";}?>>9</option>
					<option value="10"<?php if ($num == "10") {echo " selected";}?>>10</option>
				</select>
			</label></p>
            <p><label for="<?php echo $this->get_field_id("siteid"); ?>"><?php _e(PB_WIDGET_COUNTRY . ":"); ?>
				<select name="<?php echo $this->get_field_name("siteid"); ?>" id="<?php echo $this->get_field_id("siteid"); ?>" class="widefat" >
					<option value="1"<?php if ($siteid == "1") {echo " selected";}?>>United States</option>
					<option value="4"<?php if ($siteid == "4") {echo " selected";}?>>Australia</option>
					<option value="3"<?php if ($siteid == "3") {echo " selected";}?>>Austria</option>
					<option value="5"<?php if ($siteid == "5") {echo " selected";}?>>Belgium</option>
					<option value="7"<?php if ($siteid == "7") {echo " selected";}?>>Canada</option>
					<option value="10"<?php if ($siteid == "10") {echo " selected";}?>>France</option>
					<option value="11"<?php if ($siteid == "11") {echo " selected";}?>>Germany</option>
					<option value="2"<?php if ($siteid == "2") {echo " selected";}?>>Ireland</option>
					<option value="12"<?php if ($siteid == "12") {echo " selected";}?>>Italy</option>
					<option value="16"<?php if ($siteid == "16") {echo " selected";}?>>Netherlands</option>
					<option value="13"<?php if ($siteid == "13") {echo " selected";}?>>Spain</option>
					<option value="14"<?php if ($siteid == "14") {echo " selected";}?>>Switzerland</option>
					<option value="15"<?php if ($siteid == "15") {echo " selected";}?>>United Kingdom</option>
				</select>
			</label></p>
            <p><label for="<?php echo $this->get_field_id("sort"); ?>"><?php _e(PB_WIDGET_SORT . ":"); ?>
				<select name="<?php echo $this->get_field_name("sort"); ?>" id="<?php echo $this->get_field_name("sort"); ?>" class="widefat">
					<option value="BestMatch"<?php if ($sort == "BestMatch") {echo " selected";}?>>Best Match</option>
					<option value="EndTimeSoonest"<?php if ($sort == "EndTimeSoonest") {echo " selected";}?>>Time Ending Soonest</option>
					<option value="StartTimeNewest"<?php if ($sort == "StartTimeNewest") {echo " selected";}?>>Time Newly Listed</option>
					<option value="CurrentPriceLowest"<?php if ($sort == "CurrentPriceLowest") {echo " selected";}?>>Price Lowest First</option>
					<option value="CurrentPriceHighest"<?php if ($sort == "CurrentPriceHighest") {echo " selected";}?>>Price Highest First</option>
					<option value="PricePlusShippingLowest"<?php if ($sort == "PricePlusShippingLowest") {echo " selected";}?>>(Price + Shipping) Lowest First</option>
					<option value="PricePlusShippingHighest"<?php if ($sort == "PricePlusShippingHighest") {echo " selected";}?>>(Price + Shipping) Highest First</option>
				</select>
			</label></p>
             <p><label for="<?php echo $this->get_field_id("listingtype"); ?>"><?php _e(PB_WIDGET_LIST_TYPE . ":"); ?>
				<select name="<?php echo $this->get_field_name("listingtype"); ?>" id="<?php echo $this->get_field_name("listingtype"); ?>" class="widefat">
					<option value="All"<?php if ($listingtype == "All") {echo " selected";}?>>All (Auction and BINs)</option>
					<option value="Auction"<?php if ($listingtype == "Auction") {echo " selected";}?>>Auction Only</option>
					<option value="BIN"<?php if ($listingtype == "BIN") {echo " selected";}?>>BIN Only</option>
				</select>
			</label></p>
			<p><input id="<?php echo $this->get_field_id("freeshipping"); ?>" name="<?php echo $this->get_field_name("freeshipping"); ?>" type="checkbox" value="1" <?php if ($freeshipping == "1") {echo "checked";}?> class="checkbox" />&nbsp;&nbsp;<label for="<?php echo $this->get_field_id("freeshipping"); ?>"><?php _e(PB_WIDGET_FREE_SHIPPING); ?></label></p>
			<p><input id="<?php echo $this->get_field_id("homepage"); ?>" name="<?php echo $this->get_field_name("homepage"); ?>" type="checkbox" value="1" <?php if ($homepage == "1") {echo "checked";}?> class="checkbox" />&nbsp;&nbsp;<label for="<?php echo $this->get_field_id("homepage"); ?>"><?php _e(PB_WIDGET_HOME_PAGE); ?></label></p>
			<p><?php echo PB_WIDGET_PRICE_INSTRUCTIONS; ?></p>
			<p><label for="<?php echo $this->get_field_id("minprice"); ?>"><?php _e(PB_WIDGET_MINPRICE . ":"); ?> <input class="widefat" id="<?php echo $this->get_field_id("minprice"); ?>" name="<?php echo $this->get_field_name("minprice"); ?>" type="text" value="<?php echo $minprice; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id("maxprice"); ?>"><?php _e(PB_WIDGET_MAXPRICE . ":"); ?> <input class="widefat" id="<?php echo $this->get_field_id("maxprice"); ?>" name="<?php echo $this->get_field_name("maxprice"); ?>" type="text" value="<?php echo $maxprice; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id("sellerid"); ?>"><?php _e(PB_WIDGET_SELLER_ID . ":"); ?> <input class="widefat" id="<?php echo $this->get_field_id("sellerid"); ?>" name="<?php echo $this->get_field_name("sellerid"); ?>" type="text" value="<?php echo $sellerid; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id("minbid"); ?>"><?php _e(PB_WIDGET_MINBID . ":"); ?> <input class="widefat" id="<?php echo $this->get_field_id("minbid"); ?>" name="<?php echo $this->get_field_name("minbid"); ?>" type="text" value="<?php echo $minbid; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id("maxbid"); ?>"><?php _e(PB_WIDGET_MAXBID . ":"); ?> <input class="widefat" id="<?php echo $this->get_field_id("maxbid"); ?>" name="<?php echo $this->get_field_name("maxbid"); ?>" type="text" value="<?php echo $maxbid; ?>" /></label></p>
			<input type="hidden" id="<?php echo $this->get_field_id("id"); ?>" name="<?php echo $this->get_field_name("id"); ?>" value="<?php echo $this->number; ?>" />
         <?php
    }

}
?>