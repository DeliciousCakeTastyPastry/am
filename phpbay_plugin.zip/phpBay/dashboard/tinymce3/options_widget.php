<?php
define('WP_USE_THEMES', false);
$abspath = $_SERVER['SCRIPT_FILENAME'];
$pos = strpos($abspath, "\\");
if ($pos === false) {
	$pos = strpos($abspath, "/wp-content/");
	$abspath = substr($abspath, 0, $pos);
	require_once($abspath . "/wp-blog-header.php");
} else {
	$pos = strpos($abspath, "\\wp-content\\");
	$abspath = substr($abspath, 0, $pos);
	require_once($abspath . "\\wp-blog-header.php");
}
$_REQUEST['tinymce'] = base64_decode($_REQUEST['tinymce']);
$pb_temp = get_option("pb_options");
if (!empty($pb_temp)) {
	foreach ($pb_temp as $key => $option)
	$pb_options[$key] = $option;
}
$options = "";
$pb_temp = get_option("widget_phpbay_widget");
if (!empty($pb_temp)) {
	foreach ($pb_temp as $key)
	if (count($key) > 9) {
		$options .= "\t\t\t\t" . '<option value="' . $key['id'] . '">' . $key['keywords'] . " - (" . $key['id'] . ")</option>\r\n";
	}
}
if (!defined("WP_CONTENT_URL")){define('WP_CONTENT_URL', get_option( 'siteurl' ) . '/wp-content' );}
if (!defined("WP_CONTENT_DIR")){define('WP_CONTENT_DIR', ABSPATH . 'wp-content' );}
if (!defined("WP_PLUGIN_URL")){define('WP_PLUGIN_URL', WP_CONTENT_URL. '/plugins' );}
if (!defined("WP_PLUGIN_DIR")){define('WP_PLUGIN_DIR', realpath(WP_CONTENT_DIR . '/plugins'));}
require_once(realpath(WP_PLUGIN_DIR . "/phpBay/lang/" . $pb_options["Language"]));
require_once(realpath(WP_PLUGIN_DIR . "/phpBay/dashboard/sidebarwidget.php"));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo PB_WIDGET_PAGE_TITLE; ?></title>
<link rel="stylesheet" type="text/css" media="all" href="options.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $_REQUEST['tinymce']; ?>tiny_mce_popup.js"></script>
<script type="text/javascript">
var phpBayPro = {
    local_ed : 'ed',
    init : function(ed) {
        phpBayPro.local_ed = ed;
        tinyMCEPopup.resizeToInnerSize();
    },
    insert : function InsertphpBayPro(ed) {
		var tag = '[phpbaysidebar';
		if (jQuery('#options input#title').val() > "") {
			tag += ' title="' + jQuery('#options input#title').val() + '"';}

		if (jQuery('#options input#keyword').val() > "") {
			tag += ' keywords="' + jQuery('#options input#keyword').val() + '"';}

		if (jQuery('#options select#number').val() > "") {
			tag += ' num="' + jQuery('#options select#number').val() + '"';}

		if (jQuery('#options select#siteid').val() > "") {
			tag += ' siteid="' + jQuery('#options select#siteid').val() + '"';}

		if (jQuery('#options input#category').val() > "") {
			tag += ' category="' + jQuery('#options input#category').val() + '"';}

		if (jQuery('#options input#customid').val() > "") {
			tag += ' customid="' + jQuery('#options input#customid').val() + '"';}

		if (jQuery('#options select#sortorder').val() > "") {
			tag += ' sort="' + jQuery('#options select#sortorder').val() + '"';}

		if (jQuery('#options input#minprice').val() > "") {
			tag += ' minprice="' + jQuery('#options input#minprice').val() + '"';}

		if (jQuery('#options input#maxprice').val() > "") {
			tag += ' maxprice="' + jQuery('#options input#maxprice').val() + '"';}

		if (jQuery('#options input#sellerid').val() > "") {
			tag += ' sellerid="' + jQuery('#options input#sellerid').val() + '"';}

		if (jQuery('#freeshipping').is(":checked")) {
			tag += ' freeshipping="true"';}
		
		if (jQuery('#options select#override').val() > "") {
			tag += ' id="' + jQuery('#options select#override').val() + '"';}

		tag += ']';
					
		if (jQuery('#options input#keyword').val() > "") {
			tinyMCEPopup.execCommand('mceInsertContent', false, tag);
		}
        tinyMCEPopup.close();
    }
};
tinyMCEPopup.onInit.add(phpBayPro.init, phpBayPro);
document.write('<base href="'+tinymce.baseURL+'" />');
function is_columns() {
var list = new Array();
var state = document.getElementById("toggleColumns").style.display;
if (list.indexOf(template) > -1) {
	document.getElementById("toggleColumns").style.display = 'block';
} else {
	document.getElementById("toggleColumns").style.display = 'none';
}
}
</script>
<base target="_self" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?php if (is_active_widget(false, false, "phpbay_widget")) {?> 
<div id="options">
	<form method="get" name="options" action="" onSubmit="javascript:phpBayPro.insert(phpBayPro.local_ed);">
		<fieldset>
			<legend><?php echo PB_WIDGET_PAGE_TITLE; ?></legend>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td valign="top">
			<label for="title"><span class="required">*</span> <?php echo PB_WIDGET_TITLE; ?>:</label><br />
			<input name="title" type="text" id="title" size="10" value="" style="width:160px;" /> 
		</td>
		<td valign="top">
			<label for="siteid"><?php echo PB_WIDGET_COUNTRY . ":"; ?></label><br />
		<select name="siteid" id="siteid" style="width:160px;">
			<option value="1"<?php if ($pb_options["siteId"] == "1") {echo " selected";}?>>United States</option>
			<option value="4"<?php if ($pb_options["siteId"] == "4") {echo " selected";}?>>Australia</option>
			<option value="3"<?php if ($pb_options["siteId"] == "3") {echo " selected";}?>>Austria</option>
			<option value="5"<?php if ($pb_options["siteId"] == "5") {echo " selected";}?>>Belgium</option>
			<option value="7"<?php if ($pb_options["siteId"] == "7") {echo " selected";}?>>Canada</option>
			<option value="10"<?php if ($pb_options["siteId"] == "10") {echo " selected";}?>>France</option>
			<option value="11"<?php if ($pb_options["siteId"] == "11") {echo " selected";}?>>Germany</option>
			<option value="2"<?php if ($pb_options["siteId"] == "2") {echo " selected";}?>>Ireland</option>
			<option value="12"<?php if ($pb_options["siteId"] == "12") {echo " selected";}?>>Italy</option>
			<option value="16"<?php if ($pb_options["siteId"] == "16") {echo " selected";}?>>Netherlands</option>
			<option value="13"<?php if ($pb_options["siteId"] == "13") {echo " selected";}?>>Spain</option>
			<option value="14"<?php if ($pb_options["siteId"] == "14") {echo " selected";}?>>Switzerland</option>
			<option value="15"<?php if ($pb_options["siteId"] == "15") {echo " selected";}?>>United Kingdom</option>
		</select>
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="keyword"><span class="required">*</span> <?php echo PB_WIDGET_KEYWORDS; ?>:</label><br />
			<input name="keyword" type="text" id="keyword" size="10" value="" style="width:160px;" /> 
		</td>
		<td valign="top">
			<label for="category"><?php echo PB_WIDGET_CATEGORY; ?>:</label><br />
			<input name="category" type="text" id="category" size="10" value="" style="width:160px;" /> 
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="number"><span class="required">*</span> <?php echo PB_WIDGET_NUMBER; ?>:</label><br />
			<select name="number" id="number" class="widefat" style="width:160px;">
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
			</select>
		</td>
		<td valign="top">
			<label for="sortorder"><?php echo PB_WIDGET_SORT; ?>:</label><br />
		<select name="sortorder" id="sortorder" style="width:160px;">
			<option value="BestMatch"<?php if ($pb_options["sortOrder"] == "BestMatch") {echo " selected";}?>>Best Match</option>
			<option value="EndTimeSoonest"<?php if ($pb_options["sortOrder"] == "EndTimeSoonest") {echo " selected";}?>>Time Ending Soonest</option>
			<option value="StartTimeNewest"<?php if ($pb_options["sortOrder"] == "StartTimeNewest") {echo " selected";}?>>Time Newly Listed</option>
			<option value="CurrentPriceLowest"<?php if ($pb_options["sortOrder"] == "CurrentPriceLowest") {echo " selected";}?>>Price Lowest First</option>
			<option value="CurrentPriceHighest"<?php if ($pb_options["sortOrder"] == "CurrentPriceHighest") {echo " selected";}?>>Price Highest First</option>
			<option value="PricePlusShippingLowest"<?php if ($pb_options["sortOrder"] == "PricePlusShippingLowest") {echo " selected";}?>>(Price + Shipping) Lowest First</option>
			<option value="PricePlusShippingHighest"<?php if ($pb_options["sortOrder"] == "PricePlusShippingHighest") {echo " selected";}?>>(Price + Shipping) Highest First</option>
		</select>
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="customid"><?php echo PB_WIDGET_CUSTOM_ID; ?>:</label><br />
			<input name="customid" type="text" id="customid" size="10" value="" style="width:160px;" /> 
		</td>
		<td valign="top">
			<label for="override"><?php echo PB_WIDGET_OVERRIDE; ?></label><br />
			<select name="override" id="override" style="width:160px;">
<?php echo $options; ?>
			</select>
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="minprice"><?php echo PB_WIDGET_MINPRICE; ?>:</label><br />
			<input name="minprice" type="text" id="minprice" size="10" value="" style="width:160px;" /> 
		</td>
		<td valign="top">
			<label for="maxprice"><?php echo PB_WIDGET_MAXPRICE; ?>:</label><br />
			<input name="maxprice" type="text" id="maxprice" size="10" value="" style="width:160px;" /> 
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="sellerid"><?php echo PB_WIDGET_SELLER_ID; ?>:</label><br />
            <input id="sellerid" name="sellerid" type="text" value="" style="width:160px;" />

		</td>
		<td valign="top">
			<label for="freeshipping" class="checkbox">
			<input type="checkbox" name="freeshipping" id="freeshipping" value="true" />&nbsp;&nbsp;&nbsp;<?php echo PB_POPUP_SEARCH_FREE_SHIPPING; ?></label>
		</td>
	</tr>
	<tr>
		<td valign="top"></td>
		<td valign="top">
        	<br />
			<input type="submit" class="submit" id="submit" value="Submit" />
		</td>
	</tr>
</table>
		</fieldset>
	</form>
                    
	</div>
<?php } else { ?>
<p><?php echo PB_WIDGET_ERROR; ?></p>
<?php } ?> 
</body>
</html>