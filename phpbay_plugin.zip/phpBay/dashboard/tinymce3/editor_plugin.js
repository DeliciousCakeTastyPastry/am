(function() {
var Base64 = {
	_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
	encode : function (input) {
		var output = "";
		var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
		var i = 0;
		input = Base64._utf8_encode(input);
		while (i < input.length) {
			chr1 = input.charCodeAt(i++);
			chr2 = input.charCodeAt(i++);
			chr3 = input.charCodeAt(i++);
			enc1 = chr1 >> 2;
			enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
			enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
			enc4 = chr3 & 63;
			if (isNaN(chr2)) {
				enc3 = enc4 = 64;
			} else if (isNaN(chr3)) {
				enc4 = 64;
			}
			output = output +
			this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
			this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
		}
		return output;
	},
 
	decode : function (input) {
		var output = "";
		var chr1, chr2, chr3;
		var enc1, enc2, enc3, enc4;
		var i = 0;
		input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
		while (i < input.length) {
			enc1 = this._keyStr.indexOf(input.charAt(i++));
			enc2 = this._keyStr.indexOf(input.charAt(i++));
			enc3 = this._keyStr.indexOf(input.charAt(i++));
			enc4 = this._keyStr.indexOf(input.charAt(i++));
			chr1 = (enc1 << 2) | (enc2 >> 4);
			chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
			chr3 = ((enc3 & 3) << 6) | enc4;
			output = output + String.fromCharCode(chr1);
			if (enc3 != 64) {
				output = output + String.fromCharCode(chr2);
			}
			if (enc4 != 64) {
				output = output + String.fromCharCode(chr3);
			}
		}
		output = Base64._utf8_decode(output);
		return output;
	},
 
	// private method for UTF-8 encoding
	_utf8_encode : function (string) {
		string = string.replace(/\r\n/g,"\n");
		var utftext = "";
		for (var n = 0; n < string.length; n++) {
			var c = string.charCodeAt(n);
			if (c < 128) {
				utftext += String.fromCharCode(c);
			}
			else if((c > 127) && (c < 2048)) {
				utftext += String.fromCharCode((c >> 6) | 192);
				utftext += String.fromCharCode((c & 63) | 128);
			}
			else {
				utftext += String.fromCharCode((c >> 12) | 224);
				utftext += String.fromCharCode(((c >> 6) & 63) | 128);
				utftext += String.fromCharCode((c & 63) | 128);
			}
		}
		return utftext;
	},
 
	// private method for UTF-8 decoding
	_utf8_decode : function (utftext) {
		var string = "";
		var i = 0;
		var c = c1 = c2 = 0;
		while ( i < utftext.length ) {
			c = utftext.charCodeAt(i);
			if (c < 128) {
				string += String.fromCharCode(c);
				i++;
			}
			else if((c > 191) && (c < 224)) {
				c2 = utftext.charCodeAt(i+1);
				string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
				i += 2;
			}
			else {
				c2 = utftext.charCodeAt(i+1);
				c3 = utftext.charCodeAt(i+2);
				string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
				i += 3;
			}
		}
		return string;
	}
}

// Load TinyMCE Plugin code based on whether using TinyMCE3 or TinyMCE4
if (tinymce.majorVersion == 3) {
	//Load Custom phpBay Pro Button via TinyMce3
	tinymce.create('tinymce.plugins.phpBayPlugin', {
		init : function(ed, url) {
			var t = this;
			ed.onInit.add(function() {
				if (ed.settings.content_css !== false) {
					//This is necessry to load in any external css styles.
					//In this case, we want an image behind the MCE SplitButton
					//so we use CSS styling to place the button in the SplitButton
					dom = ed.windowManager.createInstance('tinymce.dom.DOMUtils', document);
					dom.loadCSS(url + '/style.css');
				}
			});
	  
			//This code builds popup window command for the first option in the SplitButton.
			//We need to pass the tinyMCE base URL so that once in the popup, we can tell it
			//to send the options in a pre-defined [phpbay] tag back to the Wordpress editor.
			ed.addCommand('phpBayOptionsPage1', function() {
				ed.windowManager.open({
					file : url + '/options_search.php?tinymce='+Base64.encode(tinymce.baseURL+'/'),
					title : 'phpBay Pro - Build Search Results',
					width : 530 + 'px',
					height : 500 + 'px',
					inline : 1
				}, {
					plugin_url: url
				});
			});

			//This code builds popup window command for the second option in the SplitButton
			//We need to pass the tinyMCE base URL so that once in the popup, we can tell it
			//to send the options in a pre-defined [phpbay] tag back to the Wordpress editor.
			ed.addCommand('phpBayOptionsPage2', function() {
				ed.windowManager.open({
					file : url + '/options_widget.php?tinymce='+Base64.encode(tinymce.baseURL+'/'),
					title : 'phpBay Pro - Sidebar Widget',
					width : 530 + 'px',
					height : 455 + 'px',
					inline : 1
				}, {
					plugin_url: url
				});
			});

			//This code builds popup window command for the third option in the SplitButton
			//We need to pass the tinyMCE base URL so that once in the popup, we can tell it
			//to send the options in a pre-defined [phpbay] tag back to the Wordpress editor.
			ed.addCommand('phpBayOptionsPage3', function() {
				ed.windowManager.open({
					file : url + '/options_shortcodes.php?tinymce='+Base64.encode(tinymce.baseURL+'/'),
					title : 'phpBay Pro - Shortcode List',
					width : 530 + 'px',
					height : 455 + 'px',
					inline : 1
				}, {
					plugin_url: url
				});
			});

		},

		getInfo : function() {
			return {
				longname : 'phpBay Pro',
				author : 'Wade Wells',
				authorurl : 'http://www.phpbay.com',
				infourl : 'http://www.phpbay.com/phpbay-pro-wordpress-plugin.html',
				version : tinymce.majorVersion + "." + tinymce.minorVersion
			};
		},

		//This creates the actual SplitButton Control.  To it, we add the Menu Titles.
		//The first title is set to disabled, as it's more of an instruction to select one
		//of the options below.  The next two are the actual menu items along with the
		//name of the Command we created earlier for each of these items (the popup pages).
		createControl: function(n, cm, url) {
			switch (n) {
				case 'phpBay':
					var c = cm.createSplitButton('phpBay', {
						title : 'phpBay Pro',
					'	class': 'phpBaySplitButton'
					});

					c.onRenderMenu.add(function(c, m) {
						m.add({title : 'phpBay Pro - Select Option Below', 'class' : 'mceMenuItemTitle'}).setDisabled(1);
						m.add({title : 'Search Results', cmd : 'phpBayOptionsPage1'});
						m.add({title : 'Sidebar Widget', cmd : 'phpBayOptionsPage2'});
						m.add({title : 'Shortcode List', cmd : 'phpBayOptionsPage3'});
					});
					return c;
			}
        	return null;
		}
	});
	//Register the tinyMCE Plugin with an appropriate name so as not to conflict with other plugins.
	tinymce.PluginManager.add('phpBay', tinymce.plugins.phpBayPlugin);
} else {
	//Load Custom phpBay Pro Button via TinyMce4
	tinymce.PluginManager.add('phpBay', function(editor, url) {
		editor.on('init', function() {
			//load in custom CSS for splitbutton
			tinymce.DOM.loadCSS(url + '/style.css');
		});

		editor.addButton('phpBay', {
			type: 'menubutton',
			tooltip: 'phpBay Pro',
			icon: false,
			classes: "widget btn splitbtn menubtn phpBaySplitButton",
				menu: [
					{text: 'Search Results', onclick: function() {
            			editor.windowManager.open({
                			title: 'phpBay Pro - Build Search Results',
                			url: url + '/options_search.php?tinymce='+Base64.encode(tinymce.baseURL+'/'),
                			width: 530,
                			height: 500,
            			});
					}},
					{text: 'Sidebar Widget', onclick: function() {
            			editor.windowManager.open({
                			title: 'phpBay Pro - Sidebar Widget',
                			url: url + '/options_widget.php?tinymce='+Base64.encode(tinymce.baseURL+'/'),
                			width: 530,
                			height: 455,
            			});
					}},
					{text: 'Shortcode List', onclick: function() {
            			editor.windowManager.open({
                			title: 'phpBay Pro - Shortcode List',
                			url: url + '/options_shortcodes.php?tinymce='+Base64.encode(tinymce.baseURL+'/'),
                			width: 530,
                			height: 455,
            			});
					}},
				]
			//}
		});

	});
	
} //end TinyMCE version check
})();