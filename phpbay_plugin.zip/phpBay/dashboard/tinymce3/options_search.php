<?php
define('WP_USE_THEMES', false);
$abspath = $_SERVER['SCRIPT_FILENAME'];
$pos = strpos($abspath, "\\");
if ($pos === false) {
	$pos = strpos($abspath, "/wp-content/");
	$abspath = substr($abspath, 0, $pos);
	require_once($abspath . "/wp-blog-header.php");
} else {
	$pos = strpos($abspath, "\\wp-content\\");
	$abspath = substr($abspath, 0, $pos);
	require_once($abspath . "\\wp-blog-header.php");
}
$_REQUEST['tinymce'] = base64_decode($_REQUEST['tinymce']);
$pb_temp = get_option("pb_options");
if (!empty($pb_temp)) {
	foreach ($pb_temp as $key => $option)
	$pb_options[$key] = $option;
}
if (!defined("WP_CONTENT_URL")){define('WP_CONTENT_URL', get_option( 'siteurl' ) . '/wp-content' );}
if (!defined("WP_CONTENT_DIR")){define('WP_CONTENT_DIR', ABSPATH . 'wp-content' );}
if (!defined("WP_PLUGIN_URL")){define('WP_PLUGIN_URL', WP_CONTENT_URL. '/plugins' );}
if (!defined("WP_PLUGIN_DIR")){define('WP_PLUGIN_DIR', realpath(WP_CONTENT_DIR . '/plugins'));}
require_once(realpath(WP_PLUGIN_DIR . "/phpBay/lang/" . $pb_options["Language"]));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo PB_POPUP_SEARCH_TITLE; ?></title>
<link rel="stylesheet" type="text/css" media="all" href="options.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $_REQUEST['tinymce']; ?>tiny_mce_popup.js"></script>
<script type="text/javascript">
var phpBayPro = {
    local_ed : 'ed',
    init : function(ed) {
        phpBayPro.local_ed = ed;
        tinyMCEPopup.resizeToInnerSize();
    },
    insert : function InsertphpBayPro(ed) {
		var tag = '[phpbay';
		if (jQuery('#options input#keyword').val() > "") {
			tag += ' keywords="' + jQuery('#options input#keyword').val() + '"';}

		if (jQuery('#options input#number').val() > "") {
			tag += ' num="' + jQuery('#options input#number').val() + '"';}

		if (jQuery('#options select#siteid').val() > "") {
			tag += ' siteid="' + jQuery('#options select#siteid').val() + '"';}

		if (jQuery('#options input#category').val() > "") {
			tag += ' category="' + jQuery('#options input#category').val() + '"';}

		if (jQuery('#options input#customid').val() > "") {
			tag += ' customid="' + jQuery('#options input#customid').val() + '"';}

		if (jQuery('#options select#sortorder').val() > "") {
			tag += ' sortorder="' + jQuery('#options select#sortorder').val() + '"';}

		if (jQuery('#options input#minprice').val() > "") {
			tag += ' minprice="' + jQuery('#options input#minprice').val() + '"';}

		if (jQuery('#options input#maxprice').val() > "") {
			tag += ' maxprice="' + jQuery('#options input#maxprice').val() + '"';}

		if (jQuery('#options input#sellerid').val() > "") {
			tag += ' sellerid="' + jQuery('#options input#sellerid').val() + '"';}

		if (jQuery('#freeshipping').is(":checked")) {
			tag += ' freeshipping="true"';}

		if (jQuery('#options select#templatename').val() > "") {
			tag += ' templatename="' + jQuery('#options select#templatename').val() + '"';}

		if (jQuery('#options select#columns').val() > "") {
			tag += ' columns="' + jQuery('#options select#columns').val() + '"';}
		
		if (jQuery('#options select#itemsperpage').val() > "") {
			tag += ' itemsperpage="' + jQuery('#options select#itemsperpage').val() + '"';}
		
		if (jQuery('#options select#paging').val() == "1") {
			tag += ' paging="true"';}
			
		tag += ']';
					
		if (jQuery('#options input#keyword').val() > "") {
			tinyMCEPopup.execCommand('mceInsertContent', false, tag);
		}
        tinyMCEPopup.close();
    }
};
tinyMCEPopup.onInit.add(phpBayPro.init, phpBayPro);
document.write('<base href="'+tinymce.baseURL+'" />');
function is_columns() {
	var list = new Array();
	var template = document.getElementById("templatename").value;
<?php	
if (defined('WP_PLUGIN_DIR')) {
	$dir = realpath(WP_PLUGIN_DIR . "/phpBay/templates");
} else {
	$dir = realpath(ABSPATH . "wp-content/plugins/phpBay/templates");
}
$d = dir($dir);
$temp = array();
while (false !== ($entry = $d->read())) {
	if($entry!='.' && $entry!='..') {
		if (is_dir($dir . "/" . $entry)) {
			$temp[] = $entry;
		}
	}
}
$d->close();
$options = "";
foreach ($temp as $tempdir) {
	$d = dir($dir . "/" . $tempdir);
	$file_list = array();
	while (false !== ($entry = $d->read())) {
		if (!is_dir($dir . "/" . $entry)) {
			$file_list[] = $entry;
		}
	}
	if (in_array("phpbay.column.open.html", $file_list)) {
		echo "list.push(\"$tempdir\");\r\n";
	}
	if (!in_array("phpbay.asin.template.html", $file_list)) {
		if ($tempdir == "default") {
			$options .= "\t\t\t\t<option value=\"$tempdir\" selected>$tempdir</option>\r\n";
		} else {
			$options .= "\t\t\t\t<option value=\"$tempdir\">$tempdir</option>\r\n";
		}
	}
}
$d->close();
?>
	var state = document.getElementById("toggleColumns").style.display;
	if (list.indexOf(template) > -1) {
		//alert('indexof = ' + list.indexOf(template));
		document.getElementById("toggleColumns").style.display = 'block';
	} else {
		//alert('indexof = ' + list.indexOf(template));
		document.getElementById("toggleColumns").style.display = 'none';
		document.getElementById("columns").value = '';
	}
}
function is_paging() {
	var paging = document.getElementById("paging").value;
	if (paging == 1) {
		//alert('indexof = ' + list.indexOf(paging));
		document.getElementById("toggleItemsPerPage").style.display = 'block';
	} else {
		//alert('indexof = ' + list.indexOf(template));
		document.getElementById("toggleItemsPerPage").style.display = 'none';
		document.getElementById("itemsperpage").value = '';
	}
}
</script>
<base target="_self" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<div id="options">
	<form method="get" name="options" action="" onSubmit="javascript:phpBayPro.insert(phpBayPro.local_ed);">
		<fieldset>
			<legend><?php echo PB_POPUP_SEARCH_OPTIONS_TITLE; ?></legend>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td valign="top">
			<label for="keyword"><span class="required">*</span> <?php echo PB_POPUP_SEARCH_KEYWORD; ?></label><br />
			<input name="keyword" type="text" id="keyword" size="10" value="" style="width:160px;" /> 
		</td>
		<td valign="top">
			<label for="siteid"><?php echo PB_POPUP_SEARCH_COUNTRY; ?></label><br />
		<select name="siteid" id="siteid" style="width:160px;">
			<option value="1"<?php if ($pb_options["siteId"] == "1") {echo " selected";}?>>United States</option>
			<option value="4"<?php if ($pb_options["siteId"] == "4") {echo " selected";}?>>Australia</option>
			<option value="3"<?php if ($pb_options["siteId"] == "3") {echo " selected";}?>>Austria</option>
			<option value="5"<?php if ($pb_options["siteId"] == "5") {echo " selected";}?>>Belgium</option>
			<option value="7"<?php if ($pb_options["siteId"] == "7") {echo " selected";}?>>Canada</option>
			<option value="10"<?php if ($pb_options["siteId"] == "10") {echo " selected";}?>>France</option>
			<option value="11"<?php if ($pb_options["siteId"] == "11") {echo " selected";}?>>Germany</option>
			<option value="2"<?php if ($pb_options["siteId"] == "2") {echo " selected";}?>>Ireland</option>
			<option value="12"<?php if ($pb_options["siteId"] == "12") {echo " selected";}?>>Italy</option>
			<option value="16"<?php if ($pb_options["siteId"] == "16") {echo " selected";}?>>Netherlands</option>
			<option value="13"<?php if ($pb_options["siteId"] == "13") {echo " selected";}?>>Spain</option>
			<option value="14"<?php if ($pb_options["siteId"] == "14") {echo " selected";}?>>Switzerland</option>
			<option value="15"<?php if ($pb_options["siteId"] == "15") {echo " selected";}?>>United Kingdom</option>
		</select>
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="number"><span class="required">*</span> <?php echo PB_POPUP_SEARCH_NUMBER; ?></label><br />
			<input name="number" type="text" id="number" size="10" value="" style="width:160px;" /> 
		</td>
		<td valign="top">
			<label for="category"><?php echo PB_POPUP_SEARCH_CATEGORY; ?></label><br />
			<input name="category" type="text" id="category" size="10" value="" style="width:160px;" /> 
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="customid"><?php echo PB_POPUP_SEARCH_CUSTOM_ID; ?></label><br />
			<input name="customid" type="text" id="customid" size="10" value="" style="width:160px;" /> 
		</td>
		<td valign="top">
			<label for="sortorder"><?php echo PB_POPUP_SEARCH_SORT; ?></label><br />
		<select name="sortorder" id="sortorder" style="width:160px;">
			<option value="BestMatch"<?php if ($pb_options["SortOrder"] == "BestMatch") {echo " selected";}?>>Best Match</option>
			<option value="EndTimeSoonest"<?php if ($pb_options["SortOrder"] == "EndTimeSoonest") {echo " selected";}?>>Time Ending Soonest</option>
			<option value="StartTimeNewest"<?php if ($pb_options["SortOrder"] == "StartTimeNewest") {echo " selected";}?>>Time Newly Listed</option>
			<option value="PricePlusShippingLowest"<?php if ($pb_options["SortOrder"] == "PricePlusShippingLowest") {echo " selected";}?>>(Price + Shipping) Lowest First</option>
			<option value="PricePlusShippingHighest"<?php if ($pb_options["SortOrder"] == "PricePlusShippingHighest") {echo " selected";}?>>(Price + Shipping) Highest First</option>
		</select>
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="minprice"><?php echo PB_POPUP_SEARCH_MIN; ?></label><br />
			<input name="minprice" type="text" id="minprice" size="10" value="" style="width:160px;" /> 
		</td>
		<td valign="top">
			<label for="maxprice"><?php echo PB_POPUP_SEARCH_MAX; ?></label><br />
			<input name="maxprice" type="text" id="maxprice" size="10" value="" style="width:160px;" /> 
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="sellerid"><?php echo PB_POPUP_SEARCH_SELLERID; ?></label><br />
			<input name="sellerid" type="text" id="sellerid" size="10" value="" style="width:160px;" /> 
		</td>
		<td valign="top">
        	<div style="width:180px;padding-top:20px;float:none;">
				<label for="freeshipping" class="checkbox"><input type="checkbox" name="freeshipping" id="freeshipping" value="true" />&nbsp;&nbsp;&nbsp;<?php echo PB_POPUP_SEARCH_FREE_SHIPPING; ?></label>
            </div>
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="templatename"><?php echo PB_POPUP_SEARCH_TEMPLATE; ?></label><br />
			<select name="templatename" id="templatename" style="width:160px;" onChange="javascript:is_columns();">
<?php echo $options; ?>
			</select>
		</td>
		<td valign="top">
        	<div id="toggleColumns" style="display: none">
			<label for="columns"><?php echo PB_POPUP_SEARCH_COLUMNS; ?></label><br />
			<select name="columns" id="columns" style="width:160px;">
				<option value=""><?php echo PB_POPUP_SEARCH_COLUMNS_SELECT; ?></option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
			</select>
            </div>
		</td>
	</tr>
	<tr>
		<td valign="top">
			<label for="paging"><?php echo PB_POPUP_SEARCH_PAGING; ?></label><br />
			<select name="paging" id="paging" style="width:160px;" onChange="javascript:is_paging();">
				<option value="1"><?php echo PB_POPUP_SEARCH_PAGING_YES; ?></option>
				<option value="0"><?php echo PB_POPUP_SEARCH_PAGING_NO; ?></option>
			</select>
        </td>
		<td valign="top">
        	<div id="toggleItemsPerPage" style="display: none">
			<label for="itemsperpage"><?php echo PB_POPUP_SEARCH_ITEMS_PER_PAGE; ?></label><br />
			<select name="itemsperpage" id="itemsperpage" style="width:160px;">
				<option value=""><?php echo PB_POPUP_SEARCH_ITEMS_PER_PAGE_SELECT; ?></option>
				<option value="10">10</option>
				<option value="20">20</option>
				<option value="30">30</option>
				<option value="40">40</option>
				<option value="50">50</option>
			</select>
            </div>
		</td>
	</tr>
	<tr>
		<td valign="top">
        </td>
		<td valign="top">
        	<br />
			<input type="submit" class="submit" id="submit" value="Submit" />
		</td>
	</tr>
</table>
		</fieldset>
	</form>
<script type="text/javascript">
	is_paging();
</script>                 
	</div>
</body>
</html>