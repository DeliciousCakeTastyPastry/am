<?php
define('WP_USE_THEMES', false);
$abspath = $_SERVER['SCRIPT_FILENAME'];
$pos = strpos($abspath, "\\");
if ($pos === false) {
	$pos = strpos($abspath, "/wp-content/");
	$abspath = substr($abspath, 0, $pos);
	require_once($abspath . "/wp-blog-header.php");
} else {
	$pos = strpos($abspath, "\\wp-content\\");
	$abspath = substr($abspath, 0, $pos);
	require_once($abspath . "\\wp-blog-header.php");
}
$_REQUEST['tinymce'] = base64_decode($_REQUEST['tinymce']);
$pb_temp = get_option("pb_options");
if (!empty($pb_temp)) {
	foreach ($pb_temp as $key => $option)
	$pb_options[$key] = $option;
}
if (!defined("WP_CONTENT_URL")){define('WP_CONTENT_URL', get_option( 'siteurl' ) . '/wp-content' );}
if (!defined("WP_CONTENT_DIR")){define('WP_CONTENT_DIR', ABSPATH . 'wp-content' );}
if (!defined("WP_PLUGIN_URL")){define('WP_PLUGIN_URL', WP_CONTENT_URL. '/plugins' );}
if (!defined("WP_PLUGIN_DIR")){define('WP_PLUGIN_DIR', realpath(WP_CONTENT_DIR . '/plugins'));}
require_once(realpath(WP_PLUGIN_DIR . "/phpBay/lang/" . $pb_options["Language"]));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo PB_POPUP_SHORTCODE_TITLE; ?></title>
<link rel="stylesheet" type="text/css" media="all" href="options.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $_REQUEST['tinymce']; ?>tiny_mce_popup.js"></script>
<base target="_self" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<div id="options">
	<form method="get" name="options" action="">
		<fieldset>
			<legend><?php echo PB_POPUP_SHORTCODE_LEGEND; ?></legend>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td valign="top">
			<textarea name="222" cols="90" rows="30">
This is a quick reference only.  Please read the user manual for acceptable values and additional details on each of these shortcodes.

keywords=""
num=""
campaignid=""
category=""
columns=""
customid=""
datetype=""
debug=""
descriptionsearch=""
displaylogo=""
displaysortbox=""
excludecategory=""
freeshipping=""
geotarget=""
itemsperpage=""
listingtype=""
minbid=""
maxbid=""
minprice=""
maxprice=""
maxdistance=""
postalcode=""
paging=""
paypalonly=""
removeduplicates=""
sellerid=""
siteid=""
skimlinks=""
sort=""
sortorder=""
templatename=""
topratedseller=""
viglinks=""
            </textarea>
		</td>
	</tr>
</table>
		</fieldset>
	</form>
<script type="text/javascript">
	is_paging();
</script>                 
	</div>
</body>
</html>