<?php
##############################################################
# The following are default string/replace that have been in
# phpBay Pro the past two years.  I recommend not replacing or
# altering them.  Towards the bottom, you can add your own custom
# str_replace() functions to further fine tune the title.
$text = str_replace("/", " ", $text);
$text = str_replace("_", " ", $text);
$text = str_replace("~", " ", $text);
$text = str_replace("-", " ", $text);
$text = str_replace("  ", " ", trim($text));
$text = str_replace("  ", " ", trim($text));
##############################################################
# This line removes ALL non alpha/numerica characters from the
# title.  It can sometimes remove things you don't want, such as
# apostrophes, or commas, periods or special symbols that are
# non-alphanumeric.  In such case, you can comment this line out
# and manually add str_replace() calls below to maintain strict
# control over what you want displayed and not.
$text = preg_replace("/[^A-Za-z0-9\s\s+]/","",$text);
##############################################################
# Create as many find/replace lines of code as needed
# replace "find" with the text you want to find
# and "replace" with the text you want to replace
# for example, if there is a character in an ebay auction title
# such as "%" that you do not want, use:
# $text = str_replace("%", "", $text);
# this will replace "%" with nothing ("") and remove it from the title string
$text = str_replace("find_this", "replace_this", $text);
?>